"""Convert an approved, already downloaded Gold snapshot to CSV without cloud calls.

CSV-only export: the bundled Artifact Tool documents CSV import but no CSV export.
PyArrow reads the Parquet payload; csv writes RFC4180 and an independent typed
readback compares every exported cell with its original value.
"""
import argparse
import csv
from datetime import date, datetime
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import sys

import pyarrow as pa
import pyarrow.parquet as pq

EXPECTED_DATASETS = {
    'indicador_municipio': 23995,
    'resultado_vs_meta': 10948,
    'evolucao_temporal': 52,
    'validacao_cruzada_brasil': 2,
    'features_alfabetizacao': 11345,
}


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def spark_to_arrow(spec):
    if isinstance(spec, dict) and spec.get('type') == 'array':
        return pa.list_(pa.field('element', spark_to_arrow(spec['elementType']),
                                 nullable=spec.get('containsNull', True)))
    types = {'integer': pa.int32(), 'int': pa.int32(), 'long': pa.int64(),
             'bigint': pa.int64(), 'string': pa.string(), 'double': pa.float64(),
             'float': pa.float32(), 'boolean': pa.bool_()}
    if spec not in types:
        raise ValueError(f'Unsupported manifest type: {spec!r}')
    return types[spec]


def assert_type_compatible(actual, expected, label, notes):
    """A physical schema may be stricter about NULLs than the approved contract."""
    if pa.types.is_list(actual) and pa.types.is_list(expected):
        assert_type_compatible(actual.value_type, expected.value_type, label + '[]', notes)
        physical_nullable = actual.value_field.nullable
        contract_nullable = expected.value_field.nullable
        if physical_nullable and not contract_nullable:
            raise ValueError(f'Physical array permits NULL elements forbidden by manifest: {label}')
        if not physical_nullable and contract_nullable:
            notes.append({'field': label, 'kind': 'array_element_nullability',
                          'manifest_nullable': True, 'physical_nullable': False,
                          'reason': 'Physical Parquet is stricter; all values satisfy the approved nullable contract.'})
    elif actual != expected:
        raise ValueError(f'Physical type mismatch: {label}: {actual} != {expected}')


def serialize(value):
    if value is None:
        return ''
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError('Non-finite value found in approved data')
        return repr(value)
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, (str, int, Decimal)):
        return str(value)
    raise TypeError(f'Unsupported scalar: {type(value).__name__}')


def assert_typed_match(cell, original, label):
    if original is None:
        if cell != '':
            raise ValueError(f'NULL was changed: {label}')
    elif isinstance(original, bool):
        if cell not in ('true', 'false') or (cell == 'true') != original:
            raise ValueError(f'Boolean changed: {label}')
    elif isinstance(original, int):
        if int(cell) != original:
            raise ValueError(f'Integer changed: {label}')
    elif isinstance(original, float):
        parsed = float(cell)
        if not math.isfinite(parsed) or parsed != original:
            raise ValueError(f'Float changed: {label}')
        if original == 0 and math.copysign(1, parsed) != math.copysign(1, original):
            raise ValueError(f'Signed zero changed: {label}')
    elif isinstance(original, (list, dict)):
        if json.loads(cell) != original:
            raise ValueError(f'Nested JSON value changed: {label}')
    elif isinstance(original, Decimal):
        if Decimal(cell) != original:
            raise ValueError(f'Decimal changed: {label}')
    elif isinstance(original, str):
        if cell != original:
            raise ValueError(f'Text changed: {label}')
    elif isinstance(original, (date, datetime)):
        if cell != original.isoformat():
            raise ValueError(f'Date changed: {label}')
    else:
        raise TypeError(f'Unsupported readback value: {label}')


def original_rows(paths, columns):
    for path in paths:
        # ParquetFile avoids adding Hive directory names as invented data columns.
        parquet = pq.ParquetFile(path)
        for batch in parquet.iter_batches(batch_size=2048, columns=columns):
            yield from batch.to_pylist()


def convert(base, manifest_path=None, output_dir=None):
    base = Path(base).resolve()
    manifest_path = Path(manifest_path or base / 'evidencias/manifest_gold.json').resolve()
    output_dir = Path(output_dir or base / 'csv').resolve()
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if (manifest.get('status') != 'SUCCEEDED' or manifest.get('simulation') is not False
            or manifest.get('all_five_tables_validated') is not True):
        raise ValueError('Only a complete, approved official snapshot may be exported')
    run_id = manifest['run_id']
    metrics = {item['table']: item for item in manifest['table_metrics']}
    if set(metrics) != set(EXPECTED_DATASETS):
        raise ValueError('Expected the five official Gold datasets')
    for name, expected in EXPECTED_DATASETS.items():
        item = metrics[name]
        if (item.get('status') != 'VALIDATED' or item['source_count'] != expected
                or item['s3_count'] != expected or f'/run_id={run_id}/' not in item['s3_uri']):
            raise ValueError(f'Unexpected approved publication: {name}')
    output_dir.mkdir(parents=True, exist_ok=True)
    report = {'status': 'STARTED', 'cloud_calls': 0, 'source_run_id': run_id,
              'source_manifest_sha256': digest(manifest_path),
              'conversion': 'Original physical Parquet columns only; no filtering or derived columns',
              'format': {'encoding': 'UTF-8', 'delimiter': ',', 'line_ending': 'CRLF',
                         'quote': 'RFC4180 minimal double quote', 'null': '',
                         'decimal_separator': '.', 'boolean': ['true', 'false'],
                         'nested_values': 'JSON strings',
                         'source_empty_string_and_null_share_blank_CSV_representation': True},
              'datasets': []}
    for name in EXPECTED_DATASETS:
        item = metrics[name]
        columns = [field['name'] for field in item['schema']['fields']]
        paths = sorted((base / 'raw_gold' / name).rglob('*.parquet'))
        if not paths:
            raise ValueError(f'No original Parquet found for {name}')
        target = output_dir / (name + '.csv')
        if target.exists():
            raise FileExistsError(f'Preserve prior CSV: {target}')
        inventory = []
        schema_notes = []
        total = 0
        for path in paths:
            parquet = pq.ParquetFile(path)
            schema = parquet.schema_arrow
            if schema.names != columns:
                raise ValueError(f'Physical column names/order differ from approved schema: {path}')
            for spec, actual in zip(item['schema']['fields'], schema):
                label = f'{name}.{actual.name}'
                assert_type_compatible(actual.type, spark_to_arrow(spec['type']), label, schema_notes)
                contract_nullable = spec.get('nullable', True)
                if actual.nullable and not contract_nullable:
                    raise ValueError(f'Physical field permits NULL forbidden by manifest: {label}')
                if not actual.nullable and contract_nullable:
                    schema_notes.append({'field': label, 'kind': 'field_nullability',
                        'manifest_nullable': True, 'physical_nullable': False,
                        'reason': 'Physical Parquet is stricter; all values satisfy the approved nullable contract.'})
            total += parquet.metadata.num_rows
            inventory.append({'local_file': path.relative_to(base).as_posix(),
                              'bytes': path.stat().st_size, 'rows': parquet.metadata.num_rows,
                              'sha256': digest(path)})
        if total != item['s3_count']:
            raise ValueError(f'Parquet footer total differs from approved count: {name}: {total}')
        null_counts = dict.fromkeys(columns, 0)
        empty_counts = dict.fromkeys(columns, 0)
        risky_text = dict.fromkeys(columns, 0)
        keys = item['keys']
        unique = set()
        rows_written = 0
        csv.field_size_limit(10 * 1024 * 1024)
        with target.open('w', encoding='utf-8', newline='') as stream:
            writer = csv.writer(stream, dialect='excel', lineterminator='\r\n')
            writer.writerow(columns)
            for row in original_rows(paths, columns):
                key = tuple(row[k] for k in keys)
                if key in unique:
                    raise ValueError(f'Duplicate dataset natural key: {name}: {key}')
                unique.add(key)
                values = []
                for col in columns:
                    value = row[col]
                    null_counts[col] += value is None
                    empty_counts[col] += isinstance(value, str) and value == ''
                    risky_text[col] += isinstance(value, str) and value.startswith(('=', '+', '-', '@', '\t', '\r'))
                    values.append(serialize(value))
                writer.writerow(values)
                rows_written += 1
        cells_checked = 0
        rows_checked = 0
        with target.open('r', encoding='utf-8', newline='') as stream:
            reader = csv.reader(stream, dialect='excel')
            if next(reader) != columns:
                raise ValueError(f'CSV header/order changed: {name}')
            for number, original in enumerate(original_rows(paths, columns), start=2):
                try:
                    actual = next(reader)
                except StopIteration as exc:
                    raise ValueError(f'CSV truncated at {name} row {number}') from exc
                if len(actual) != len(columns):
                    raise ValueError(f'CSV shape changed: {name} row {number}')
                for col, cell in zip(columns, actual):
                    assert_typed_match(cell, original[col], f'{name}:{number}:{col}')
                    cells_checked += 1
                rows_checked += 1
            try:
                next(reader)
            except StopIteration:
                pass
            else:
                raise ValueError(f'CSV has extra rows: {name}')
        if rows_written != item['s3_count'] or rows_checked != total:
            raise ValueError(f'Count mismatch after CSV roundtrip: {name}')
        for path, recorded in zip(paths, inventory):
            if digest(path) != recorded['sha256']:
                raise ValueError(f'Source file changed during conversion: {path}')
        if any(risky_text.values()):
            # Preserve source values. These counts tell importers to disable formula conversion.
            risk_note = 'Source text with formula-like prefixes preserved; import as literal text.'
        else:
            risk_note = 'No source text with formula-like prefixes.'
        report['datasets'].append({'dataset': name, 'csv_file': target.relative_to(base).as_posix(),
            'rows': rows_written, 'columns': columns, 'source_expected_rows': item['s3_count'],
            'natural_keys': keys, 'unique_keys': len(unique), 'cells_typed_compared': cells_checked,
            'csv_bytes': target.stat().st_size, 'csv_sha256': digest(target),
            'null_counts': null_counts, 'original_empty_string_counts': empty_counts,
            'formula_like_source_text_counts': risky_text, 'formula_like_note': risk_note,
            'schema_compatibility_notes': [json.loads(value) for value in sorted(
                {json.dumps(note, sort_keys=True) for note in schema_notes})],
            'parquet_sources': inventory, 'readback_status': 'PASS'})
    report['status'] = 'PASS'
    report['total_rows'] = sum(item['rows'] for item in report['datasets'])
    report['all_cells_typed_roundtrip'] = True
    report['all_counts_match_approved_manifest'] = True
    if digest(manifest_path) != report['source_manifest_sha256']:
        raise ValueError('Approved manifest changed during conversion')
    report_path = base / 'evidencias/conversao_csv_validada.json'
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-dir', default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument('--manifest')
    parser.add_argument('--output-dir')
    args = parser.parse_args()
    report = convert(args.base_dir, args.manifest, args.output_dir)
    print(json.dumps({'status': report['status'], 'total_rows': report['total_rows'],
                      'csv_files': len(report['datasets']), 'cloud_calls': 0,
                      'all_cells_typed_roundtrip': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
