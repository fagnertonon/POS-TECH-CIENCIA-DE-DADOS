"""Bounded download of an already published Gold snapshot. No Glue/BigQuery/Athena calls."""
import argparse
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
from urllib.parse import urlparse
import zipfile
import boto3
from botocore.config import Config

def sha(data): return hashlib.sha256(data).hexdigest()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    ap.add_argument('--mode', choices=['plan', 'download'], default='plan')
    ap.add_argument('--directory', required=True)
    args = ap.parse_args()
    cfg = json.loads(Path(args.config).read_text())
    dest = Path(args.directory)
    dest.mkdir(parents=True, exist_ok=True)
    sdk_cfg = Config(retries={'max_attempts': 0}, connect_timeout=10, read_timeout=30)
    s = boto3.Session(region_name=cfg['region'])
    identity = s.client('sts', config=sdk_cfg).get_caller_identity()
    if identity['Account'] != cfg['account']:
        raise ValueError('Wrong account')
    s3 = s.client('s3', config=sdk_cfg)
    def get(bucket, key, limit, etag=None):
        params = {'Bucket': bucket, 'Key': key}
        if etag: params['IfMatch'] = etag
        r = s3.get_object(**params)
        try:
            if r['ContentLength'] > limit: raise ValueError('Object exceeds byte cap')
            data = r['Body'].read(limit + 1)
        finally: r['Body'].close()
        if len(data) > limit or len(data) != r['ContentLength']: raise ValueError('Invalid body size')
        return data, r
    if args.mode == 'plan':
        u = urlparse(cfg['manifest_uri'])
        data, response = get(u.netloc, u.path.lstrip('/'), 1048576)
        if sha(data) != cfg['manifest_sha256']: raise ValueError('Published manifest differs from approved reference')
        m = json.loads(data)
        if m['status'] != 'SUCCEEDED' or m['simulation'] is not False or m['run_id'] != cfg['run_id']:
            raise ValueError('Not approved official Gold')
        if not m['all_five_tables_validated']: raise ValueError('Incomplete publication')
        objects = []
        for table in m['table_metrics']:
            name = table['table']; expected = cfg['tables'][name]
            u = urlparse(table['s3_uri']); prefix = u.path.lstrip('/')
            if u.netloc != cfg['bucket'] or prefix != expected['prefix']:
                raise ValueError('Unexpected source location')
            r = s3.list_objects_v2(Bucket=u.netloc, Prefix=prefix, MaxKeys=128)
            if r.get('IsTruncated'): raise ValueError('Listing beyond cap')
            selected = [o for o in r.get('Contents', []) if o['Key'].endswith('.parquet')]
            if len(selected) != expected['files'] or sum(o['Size'] for o in selected) != expected['bytes']:
                raise ValueError('Object inventory changed for ' + name)
            for o in selected:
                if '/' in o['Key'][len(prefix):] or '..' in o['Key'].split('/'):
                    raise ValueError('Unexpected nested or unsafe object key')
                objects.append({'table': name, 'bucket': u.netloc, 'key': o['Key'],
                                'bytes': o['Size'], 'etag': o['ETag'],
                                'last_modified': o['LastModified'].isoformat()})
        if len(objects) != 27 or sum(o['bytes'] for o in objects) > 3 * 1024 * 1024:
            raise ValueError('Inventory exceeds exact export scope')
        (dest / 'manifest_gold.json').write_bytes(data)
        report = {'planned_at_utc': datetime.now(timezone.utc).isoformat(), 'account': cfg['account'],
                  'run_id': cfg['run_id'], 'read_only': True, 'objects': objects,
                  'object_count': len(objects), 'total_parquet_bytes': sum(o['bytes'] for o in objects),
                  'manifest_sha256': sha(data), 'manifest_etag': response.get('ETag'),
                  'calls_in_plan': {'sts_get_caller_identity': 1, 's3_get_object': 1, 's3_list_objects_v2': 5}}
        (dest / 'plano_copia.json').write_text(json.dumps(report, indent=2))
        print(json.dumps({k:v for k,v in report.items() if k != 'objects'}, indent=2))
        return
    plan = json.loads((dest / 'plano_copia.json').read_text())
    if plan['run_id'] != cfg['run_id'] or plan['manifest_sha256'] != cfg['manifest_sha256']:
        raise ValueError('Unapproved plan')
    if sha((dest / 'manifest_gold.json').read_bytes()) != cfg['manifest_sha256']:
        raise ValueError('Local approved manifest changed')
    proof = []
    for obj in plan['objects']:
        p = dest / 'raw_gold' / obj['table'] / Path(obj['key']).name
        if p.exists(): raise ValueError('Do not overwrite completed or partial download; inspect existing evidence')
        data, response = get(obj['bucket'], obj['key'], obj['bytes'], obj['etag'])
        p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)
        proof.append(dict(obj, sha256=sha(data), local_file=p.relative_to(dest).as_posix(),
                          version_id=response.get('VersionId'), server_side_encryption=response.get('ServerSideEncryption')))
    report = {'status': 'EXISTING_APPROVED_GOLD_DOWNLOADED',
              'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'objects': proof,
              'total_parquet_bytes': sum(o['bytes'] for o in proof), 'object_count': len(proof),
              'new_source_extractions': 0, 'glue_jobs_started': 0, 'athena_queries': 0,
              's3_writes': 0, 'permissions_changed': False,
              'calls_in_download': {'sts_get_caller_identity': 1, 's3_get_object': len(proof)},
              'reference_s3_requests_usd_before_allowances': str(Decimal(5)*Decimal('0.000005') + Decimal(28)*Decimal('0.0000004')),
              'request_reference_is_not_a_posted_bill': True,
              'data_transfer_and_credits_not_assumed_zero': True}
    (dest / 'copia_verificada.json').write_text(json.dumps(report, indent=2))
    archive = dest.with_suffix('.zip')
    if archive.exists(): raise ValueError('Preserve prior download archive')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(dest.rglob('*')):
            if p.is_file(): z.write(p, p.relative_to(dest).as_posix())
    print(json.dumps({k:v for k,v in report.items() if k != 'objects'}, indent=2))
    print('DOWNLOAD_ZIP=' + str(archive))

if __name__ == '__main__': main()
