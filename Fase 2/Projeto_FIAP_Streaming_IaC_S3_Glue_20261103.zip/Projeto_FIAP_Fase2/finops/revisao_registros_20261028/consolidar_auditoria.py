"""Consolidate existing local FinOps evidence. No AWS/GCP calls or installations."""
from pathlib import Path
from decimal import Decimal
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
model_path = ROOT / 'outputs/finops_pendencias_20261027/modelo_finops.json'
original_sha = sha(model_path)
assert original_sha == '97cc2f32069a916b479395c0c0026b6997335b12bd23e7f74e5a05478b38c26b'
model = read(model_path)
egress = read(OUT / 'egress_auditoria.json')
logs = read(OUT / 'logs_auditoria.json')
alt = logs['alternative_historical_storage_forecast']
assert egress['quantity']['billable_egress_bytes'] is None
assert logs['decision_original_question']['compressed_growth_gb_month_for_four_plus_four'] is None
assert Decimal(alt['sum_usage_quantity_native_gb_month']) == Decimal('0.0006137753')
assert Decimal(alt['projected_storage_usage_native_gb_month_30d']) == Decimal('0.0030688765')
assert Decimal(alt['projected_reference_usd_30d_before_free_allowances_and_credits']) == Decimal('0.000092066295')

# Preserve the exact original model. This table does not invent missing quantities.
with (OUT / 'Tabela_30_dias_cenario_original_parcial.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f)
    w.writerow(['Serviço', 'Parcela', 'Unidade', 'Quantidade medida na base', 'Base da quantidade',
                'Preço unitário USD', 'Custo mensal projetado USD', 'Situação'])
    for row in model['projection_rows']:
        qty = row.get('quantity_decimal', row['quantity'])
        cost = model['calculated_reference']['rows'][row['id']]
        w.writerow([row['service'], row['item'], row['unit'], 'n.a.' if qty is None else qty,
                    row['basis'], row['tariff_usd'], 'n.a.' if cost is None else cost,
                    'PENDENTE' if cost is None else 'Projeção do modelo histórico; ver ressalvas'])
    w.writerow(['SUBTOTAL PARCIAL', '', '', '', '', '',
                model['calculated_reference']['available_subtotal_usd'], '19 parcelas; duas não medidas'])

with (OUT / 'Logs_arquivo_cenario_historico_separado.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f)
    w.writerow(['Serviço', 'Unidade', 'Quantidade medida', 'Preço unitário USD',
                'Custo mensal projetado USD', 'Base e ressalva'])
    w.writerow(['CloudWatch Logs - armazenamento no ritmo histórico', 'GB-Month (unidade nativa CE)',
                alt['sum_usage_quantity_native_gb_month'], '0.03',
                alt['projected_reference_usd_30d_before_free_allowances_and_credits'],
                '21 a 26/10: seis dias completos; quantidade ×30/6. Estimated=true. Não representa incremento por ciclo nem cenário 4+4.'])

daily = [r for r in alt['observed_rows_all_available']
         if '2026-10-21' <= r['start_inclusive_utc'] < '2026-10-27']
with (OUT / 'Logs_arquivo_seis_dias_medidos.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(daily[0]))
    w.writeheader(); w.writerows(daily)

closure = {
    'schema': 'fiap.finops.existing-records-closure.v2', 'review_date': '2026-10-28',
    'status': 'PARTIAL_ONE_ALTERNATIVE_ARCHIVE_PROJECTION_TWO_ORIGINAL_QUANTITIES_UNAVAILABLE',
    'scope': {'new_cloud_api_calls': 0, 'new_cost_generating_operations': 0, 'billing_enabled': False,
              'new_extractions': 0, 'new_exports': 0, 'permissions_changed': False,
              'historical_files_modified': False, 'analysis_local_only': True},
    'original_30d_scenario': {'batch_cycles': 4, 'replays': 4, 'cadence_is_assumption': True,
        'measured_cost_rows': 19, 'unmeasured_cost_rows': ['gcp_egress', 'logs_archive_growth'],
        'partial_subtotal_usd': model['calculated_reference']['available_subtotal_usd'],
        'complete_total_usd': None, 'budget_total_usd': 140, 'budget_guaranteed': False,
        'model_sha256_preserved': original_sha,
        'support_requests_window_not_representative_of_four_new_ingestions': True},
    'egress': {'billable_bytes': None, 'cost_usd': None, 'missing_record':
               'Existing network SKU usage or attributed serializedResponseBytes with route/tariff proof'},
    'logs_original_growth': {'compressed_bytes_per_cycle': None, 'cost_usd': None,
        'missing_record': 'Existing resource/hour metering or comparable compressed snapshots with run attribution and retention context'},
    'logs_alternative_historical': alt,
    'latest_credit_evidence_from_prior_task': {
        'amount_usd': '135.64', 'observed_at_utc': '2026-10-28T17:27:10.278075+00:00',
        'refreshed_this_review': False, 'source': 'outputs/dashboard_local_20261028/evidencias/quicksight_readonly_20261028.json',
        'not_current_bill_or_project_total_cost': True},
    'closure_possible_without_new_costs': 'Only if missing pre-existing records can be supplied; do not recreate telemetry retrospectively or assign zero.',
}
(OUT / 'resultado_consolidado.json').write_text(json.dumps(closure, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert sha(model_path) == original_sha
print(json.dumps({'partial_subtotal_preserved': closure['original_30d_scenario']['partial_subtotal_usd'],
                  'logs_historical_reference_usd_30d': '0.000092066295', 'complete_total': None,
                  'new_cloud_calls': 0, 'original_model_sha256': original_sha}, ensure_ascii=False))
