"""Offline edge cases for archive-SKU selection and historical projection."""
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import unittest

from auditar_logs_local import extract_archive_daily, PATHS

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / PATHS['CE_daily']

class ArchiveHistoricalTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(SOURCE.read_text(encoding='utf-8'))

    def period(self, day):
        return next(t for page in self.data['pages'] for t in page['ResultsByTime']
                    if t['TimePeriod']['Start'] == day)

    def group(self, day):
        return next(g for g in self.period(day)['Groups']
                    if g['Keys'] == ['AmazonCloudWatch', 'USE2-TimedStorage-ByteHrs'])

    def test_reproduces_exact_measured_sum_and_30_day_reference(self):
        _, selected, quantity, forecast = extract_archive_daily(self.data)
        self.assertEqual(len(selected), 6)
        self.assertEqual(quantity, Decimal('0.0006137753'))
        self.assertEqual(forecast, Decimal('0.0030688765'))
        self.assertEqual(forecast * Decimal('0.03'), Decimal('0.000092066295'))

    def test_s3_same_usage_type_is_not_cloudwatch_archive(self):
        wrong_service = deepcopy(self.group('2026-10-23'))
        wrong_service['Keys'][0] = 'Amazon Simple Storage Service'
        wrong_service['Metrics']['UsageQuantity']['Amount'] = '999999'
        self.period('2026-10-23')['Groups'].append(wrong_service)
        _, _, quantity, _ = extract_archive_daily(self.data)
        self.assertEqual(quantity, Decimal('0.0006137753'))

    def test_incomplete_current_day_excluded_without_prorating(self):
        self.group('2026-10-27')['Metrics']['UsageQuantity']['Amount'] = '999999'
        all_rows, selected, quantity, _ = extract_archive_daily(self.data)
        self.assertTrue(any(r['start_inclusive_utc'] == '2026-10-27' for r in all_rows))
        self.assertFalse(any(r['start_inclusive_utc'] == '2026-10-27' for r in selected))
        self.assertEqual(quantity, Decimal('0.0006137753'))

    def test_missing_selected_day_is_error_not_zero(self):
        groups = self.period('2026-10-23')['Groups']
        groups.remove(self.group('2026-10-23'))
        with self.assertRaisesRegex(ValueError, 'Missing or duplicated'):
            extract_archive_daily(self.data)

    def test_wrong_usage_unit_is_rejected(self):
        self.group('2026-10-23')['Metrics']['UsageQuantity']['Unit'] = 'GB'
        with self.assertRaisesRegex(ValueError, 'Incompatible'):
            extract_archive_daily(self.data)

    def test_wrong_currency_unit_is_rejected(self):
        self.group('2026-10-23')['Metrics']['UnblendedCost']['Unit'] = 'EUR'
        with self.assertRaisesRegex(ValueError, 'Incompatible'):
            extract_archive_daily(self.data)

    def test_duplicate_pagination_row_cannot_double_charge(self):
        self.period('2026-10-23')['Groups'].append(deepcopy(self.group('2026-10-23')))
        with self.assertRaisesRegex(ValueError, 'Missing or duplicated'):
            extract_archive_daily(self.data)

    def test_caller_cannot_include_incomplete_day(self):
        with self.assertRaisesRegex(ValueError, 'complete UTC days'):
            extract_archive_daily(self.data, end='2026-10-28')

    def test_incomplete_pagination_is_rejected(self):
        self.data['pagination_complete'] = False
        with self.assertRaisesRegex(ValueError, 'Complete DAILY'):
            extract_archive_daily(self.data)

    def test_not_a_single_utc_day_is_rejected(self):
        self.period('2026-10-23')['TimePeriod']['End'] = '2026-10-25'
        with self.assertRaisesRegex(ValueError, 'single complete UTC day'):
            extract_archive_daily(self.data)

if __name__ == '__main__':
    unittest.main()
