"""Local-only audit of existing archive/log evidence. No cloud/network imports."""
from pathlib import Path
from decimal import Decimal
from datetime import date, datetime, timedelta, timezone
import hashlib
import json

def extract_archive_daily(daily, start='2026-10-21', end='2026-10-27',
                          completed_before='2026-10-27', forecast_days=30):
    """Extract one service/SKU and require every selected complete UTC day.

    Missing groups, duplicates and incompatible units are errors, not zero use.
    Other services sharing a usage-type suffix are deliberately excluded.
    """
    if daily.get('request', {}).get('Granularity') != 'DAILY' or daily.get('pagination_complete') is not True:
        raise ValueError('Complete DAILY Cost Explorer evidence is required')
    begin, stop, cutoff = map(date.fromisoformat, (start, end, completed_before))
    if not begin < stop <= cutoff or forecast_days <= 0:
        raise ValueError('Window must contain only complete UTC days')
    rows = []
    for page in daily['pages']:
        for period in page['ResultsByTime']:
            for group in period['Groups']:
                if group['Keys'] != ['AmazonCloudWatch', 'USE2-TimedStorage-ByteHrs']:
                    continue
                rows.append({
                    'start_inclusive_utc': period['TimePeriod']['Start'],
                    'end_exclusive_utc': period['TimePeriod']['End'],
                    'estimated': period['Estimated'],
                    'usage_amount': group['Metrics']['UsageQuantity']['Amount'],
                    'pricing_unit': group['Metrics']['UsageQuantity']['Unit'],
                    'unblended_cost_amount': group['Metrics']['UnblendedCost']['Amount'],
                    'unblended_cost_unit': group['Metrics']['UnblendedCost']['Unit'],
                })
    selected = sorted((r for r in rows if start <= r['start_inclusive_utc'] < end),
                      key=lambda r: r['start_inclusive_utc'])
    days = (stop - begin).days
    expected = [(begin + timedelta(days=i)).isoformat() for i in range(days)]
    if [r['start_inclusive_utc'] for r in selected] != expected:
        raise ValueError('Missing or duplicated selected daily archive group')
    for r in selected:
        day = date.fromisoformat(r['start_inclusive_utc'])
        if date.fromisoformat(r['end_exclusive_utc']) != day + timedelta(days=1):
            raise ValueError('Expected a single complete UTC day')
        if r['pricing_unit'] != 'GB-Month' or r['unblended_cost_unit'] != 'USD':
            raise ValueError('Incompatible archive usage or currency unit')
        amount = Decimal(r['usage_amount'])
        if not amount.is_finite() or amount < 0:
            raise ValueError('Invalid archive quantity')
    quantity = sum((Decimal(r['usage_amount']) for r in selected), Decimal(0))
    return rows, selected, quantity, quantity * Decimal(forecast_days) / Decimal(days)

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
PATHS = {
    'closure_T5': 'outputs/finops_pendencias_20261027/fechamento_logs.json',
    'raw_T5': 'outputs/finops_pendencias_20261027/raw/aws_logs/log_growth_readonly.json',
    'archive_T6': 'outputs/finops_duas_medicoes_20261027/raw/aws_archive_sources.json',
    'archive_analysis': 'outputs/finops_duas_medicoes_20261027/analise_arquivo.json',
    'data_exports': 'outputs/finops_duas_medicoes_20261027/raw/aws_data_exports_existing.json',
    'CE_monthly': 'outputs/finops_2026_10_27/aws/cost_explorer_usage_types.json',
    'CE_daily': 'outputs/finops_atualizado_20261027/raw/aws/cost_explorer_usage_types.json',
    'base_groups': 'outputs/finops_logs_2026_10_27/log_groups_baseline.json',
    'summary': 'outputs/finops_logs_2026_10_27/summary.json',
    'policy_history': 'outputs/finops_logs_2026_10_27/retention_deletion_event_metadata.json',
    'stored_metrics': 'outputs/finops_logs_2026_10_27/existing_stored_bytes_metrics.json',
    'current_model': 'outputs/finops_pendencias_20261027/modelo_finops.json',
}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    before = {k: sha(ROOT / v) for k, v in PATHS.items()}
    raw = {k: json.loads((ROOT / v).read_text(encoding='utf-8')) for k, v in PATHS.items()}
    closure, archive = raw['closure_T5'], raw['archive_analysis']
    daily = raw['CE_daily']
    rows, complete_rows, quantity, projected = extract_archive_daily(daily)
    tariff = Decimal('0.03')
    assert quantity == Decimal('0.0006137753')
    assert projected == Decimal('0.0030688765')

    report = {
        'schema': 'fiap.finops.local-log-audit.v1',
        'audit_date_client': '2026-10-28',
        'account': '637246457028', 'region': 'us-east-2',
        'decision_original_question': {
            'status': 'COMPRESSED_GROWTH_PER_CYCLE_NOT_RECOVERABLE_FROM_EXISTING_LOCAL_EVIDENCE',
            'compressed_increment_bytes_per_batch': None,
            'compressed_increment_bytes_per_replay': None,
            'compressed_growth_gb_month_for_four_plus_four': None,
            'cost_30d_original_four_plus_four_scenario': None,
            'reason': 'The existing stock snapshots are all unchanged despite positive ingestion; no compressed bytes were attributed to a batch/replay cohort or isolated billing resource/hour.',
            'missing_is_not_zero': True,
        },
        'valid_distinct_measurements': {
            'reported_archive_stock': archive['t6_reported_compressed_stock'],
            'stock_snapshots': closure['reported_stock']['captures'] + [{
                'label': 'T6', 'capture_end_utc': archive['t6_reported_compressed_stock']['capture_at_utc'],
                'stock_bytes_reported': archive['t6_reported_compressed_stock']['bytes'],
                'group_count': archive['t6_reported_compressed_stock']['groups']}],
            'all_six_captures_report_same_stock': all(
                c['stock_bytes_reported'] == 7417226 for c in closure['reported_stock']['captures'])
                and archive['t6_reported_compressed_stock']['bytes'] == 7417226,
            'latest_stock_net_delta_bytes': 0,
            'stock_delta_does_not_measure_generated_compressed_bytes': True,
            'observed_ingestion_uncompressed_bytes': 6216753,
            'observed_ingestion_log_events': 27113,
            'ingestion_window_start_utc': '2026-10-27T00:00:00Z',
            'ingestion_window_end_exclusive_utc': '2026-10-27T18:00:00Z',
            'ingestion_is_not_archive_bytes': True,
            'existing_storedbytes_metric_identities': 0,
            'cloudtrail_retention_deletion_findings': archive['cloudtrail'],
        },
        'alternative_historical_storage_forecast': {
            'status': 'NUMERIC_SCENARIO_BASED_ON_EXISTING_ESTIMATED_CE_METERING',
            'service': 'AmazonCloudWatch',
            'usage_type': 'USE2-TimedStorage-ByteHrs',
            'observed_pricing_unit': 'GB-Month',
            'observed_rows_all_available': rows,
            'selected_window_start_utc': '2026-10-21T00:00:00Z',
            'selected_window_end_exclusive_utc': '2026-10-27T00:00:00Z',
            'completed_utc_days': 6,
            'all_selected_days_have_actual_returned_usage_group': True,
            'sum_usage_quantity_native_gb_month': str(quantity),
            'projection_formula': 'SUM(usage_amount in the six complete selected UTC days) * 30 / 6',
            'projected_storage_usage_native_gb_month_30d': str(projected),
            'reference_tariff_usd_per_gb_month': str(tariff),
            'projected_reference_usd_30d_before_free_allowances_and_credits': str(projected * tariff),
            'selected_unblended_cost_sum_usd': str(sum(Decimal(r['unblended_cost_amount']) for r in complete_rows)),
            'all_ce_rows_estimated': all(r['estimated'] for r in complete_rows),
            'response_captured_http_date_utc': [p.get('ResponseMetadata', {}).get('HTTPHeaders', {}).get('date') for p in daily['pages']],
            'report_request': daily['request'],
            'pagination_complete': daily['pagination_complete'],
            'excluded_current_day': '2026-10-27 is incomplete at the capture instant; its 0.0002228299 GB-Month is excluded.',
            'excluded_missing_archive_days': 'No zero is imputed for earlier dates without the selected usage group, including 2026-10-20.',
            'period_representativeness': 'Six-day historical account/Ohio archive rhythm, not one representative Bronze-Silver-Gold+replay cycle. Initial Bronze on 20/10 and replay on 27/10 are not in this selected window.',
            'not_measured': ['per-cycle compression', 'exact individual run attribution', 'future four-batch/four-replay archive increment', 'final posted billing'],
            'zero_cost_caveat': 'The saved query filters RECORD_TYPE=Usage. Zero UnblendedCost is an observed charge, but does not itself identify credits or prove a zero production unit price. Do not assume all zero is caused by credits.',
            'avoid_double_counting': 'If used in a separate historical scenario, this whole archive-service forecast REPLACES the archive-stock and archive-growth lines for that scenario. It is not added to their amounts or substituted into the original 4+4 model as measured growth.',
        },
        'api_assessment_not_executed': {
            'no_additional_call_is_necessary_for_the_numeric_historical_alternative': True,
            'describe_log_groups': 'A later read could provide a later aggregate stock; it cannot reconstruct per-cycle compressed history without attribution and coverage. Current pricing/eligibility must be verified separately before any no-new-cost promise; this audit does not make a new call.',
            'cloudtrail_lookup_events': 'Existing paginated event-history findings already exclude observed explicit deletions and record unchanged retention; another lookup would not provide compressed byte counts.',
            'describe_log_streams': 'No trustworthy per-stream compressed archive quantity can be inferred from saved stream metadata; do not sum deprecated/zero stream storedBytes as a replacement.',
            'avoid': ['GetMetricData/GetMetricStatistics billed API calls without verified allowance', 'Cost Explorer new paid queries', 'Logs Insights queries', 'new log exports to S3', 'new test jobs/replay', 'retention changes', 'new custom metrics', 'CUR/Data Exports creation'],
        },
        'existing_billing_export_discovery_limitations': archive['billing_sources'],
        'scope': {'new_aws_calls': 0, 'new_gcp_calls': 0, 'new_network_calls': 0,
                  'cloud_mutations': 0, 'exports_started': 0, 'billing_activated': False,
                  'historical_model_modified': False, 'compression_ratio_inferred': False,
                  'unavailable_growth_assigned_zero': False},
        'source_files': [{'key': k, 'path': str((ROOT / v).resolve()), 'sha256': before[k]} for k, v in PATHS.items()],
    }
    for k, v in PATHS.items():
        assert sha(ROOT / v) == before[k], 'Original modified: ' + v
    dest = OUT / 'logs_auditoria.json'
    dest.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'path': str(dest), 'original_growth_closed': False,
                      'historical_alternative_projected_gb_month': str(projected),
                      'historical_alternative_projected_usd': str(projected * tariff),
                      'network_calls': 0, 'model_original_unchanged': True}, ensure_ascii=False))


if __name__ == "__main__":
    main()
