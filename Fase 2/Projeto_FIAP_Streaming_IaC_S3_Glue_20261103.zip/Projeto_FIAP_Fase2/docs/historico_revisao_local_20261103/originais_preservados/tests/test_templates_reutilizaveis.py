"""Offline checks of new templates, preserving historical bytes and safety bounds."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


stream = load('reusable_streaming_builder', 'streaming/build_stack.py')
alerts = load('reusable_alert_builder', 'infra/gerar_observabilidade.py')


class ReusableTemplates(unittest.TestCase):
    def test_historical_streaming_baseline_is_preserved(self):
        baseline = json.loads((ROOT / 'streaming/streaming_stack.json').read_text(encoding='utf-8'))
        self.assertEqual(stream.build(), baseline)

    def test_streaming_custom_names_permissions_and_compute_caps(self):
        template = stream.build(bucket_name='outro-bucket-local', function_name='outra-funcao',
                                queue_name='outra-fila', role_name='outra-role', pipeline='outro-pipeline')
        resources = template['Resources']
        self.assertEqual(template['Parameters']['BucketName']['Default'], 'outro-bucket-local')
        props = resources['ConsumerFunction']['Properties']
        self.assertEqual((props['FunctionName'], props['MemorySize'], props['Timeout'], props['ReservedConcurrentExecutions']),
                         ('outra-funcao', 256, 10, 2))
        self.assertEqual(resources['SourceQueue']['Properties']['QueueName'], 'outra-fila')
        self.assertIn("PIPELINE = 'outro-pipeline'", props['Code']['ZipFile'])
        self.assertEqual(resources['RejectedEventAlarm']['Properties']['Dimensions'], [{'Name': 'Pipeline', 'Value': 'outro-pipeline'}])
        self.assertIn('PIPELINE = "fiap-inep-streaming"', (ROOT / 'streaming/lambda_function.py').read_text(encoding='utf-8'))
        statement = resources['ConsumerRole']['Properties']['Policies'][0]['PolicyDocument']['Statement'][1]
        self.assertEqual(statement['Action'], ['s3:GetObject', 's3:PutObject'])
        for item in statement['Resource']:
            if '/auditoria/' not in item['Fn::Sub']:
                self.assertIn('inep_streaming', item['Fn::Sub'])
            self.assertNotIn('/gold/inep/', item['Fn::Sub'])
            self.assertNotIn('/silver/inep/', item['Fn::Sub'])

    def test_optional_streaming_alarm_actions_are_bounded(self):
        arn = 'arn:aws:sns:eu-west-1:123456789012:grupo-alertas'
        template = stream.build(bucket_name='outro-bucket-local', alert_topic_arn=arn)
        for logical in ('DeadLetterAlarm', 'RejectedEventAlarm', 'QueueAgeAlarm'):
            self.assertEqual(template['Resources'][logical]['Properties']['AlarmActions'], [{'Ref': 'AlertTopicArn'}])
        self.assertEqual(template['Parameters']['AlertTopicArn']['Default'], arn)

    def test_invalid_names_are_refused_before_any_output(self):
        for kwargs in ({'bucket_name': '../outside'}, {'bucket_name': 'foo..bar'}, {'bucket_name': '192.168.1.1'},
                       {'role_name': 'role/with/path'}, {'alert_topic_arn': 'not-an-arn'}):
            with self.assertRaises(ValueError):
                stream.build(**kwargs)
        with self.assertRaises(ValueError):
            alerts.build(rule_name='../outside')
        with self.assertRaises(ValueError):
            alerts.build(silver_job='abc-batch', gold_job='abc')

    def test_new_observability_template_has_no_masked_endpoint_or_account(self):
        template = alerts.build(topic_name='meu-topico', silver_job='meu-silver', gold_job='meu-gold')
        serialized = json.dumps(template)
        self.assertNotIn('637246457028', serialized)
        self.assertNotIn('r***@fiap.com.br', serialized)
        self.assertEqual(template['Parameters']['AlertEmail']['Default'], '')
        subscription = template['Resources']['AlertSubscription']
        self.assertEqual(subscription['Condition'], 'EnableEmail')
        self.assertEqual(subscription['Properties']['Endpoint'], {'Ref': 'AlertEmail'})
        rule = template['Resources']['BatchFailureRule']['Properties']
        self.assertNotIn('ScheduleExpression', rule)
        self.assertEqual(rule['EventPattern']['detail']['jobName'], [{'Ref': 'BronzeJobName'}, {'Ref': 'SilverJobName'}, {'Ref': 'GoldJobName'}])
        policy = template['Resources']['AlertTopicPolicy']['Properties']['PolicyDocument']['Statement']
        event_rule = next(item for item in policy if item['Sid'] == 'OnlyEventBridgeFromThisAccount')
        self.assertIn('${AWS::AccountId}:rule/', event_rule['Condition']['ArnEquals']['aws:SourceArn']['Fn::Sub'])

    def test_generation_refuses_overwrite_and_preserves_historical_evidence(self):
        historical = ROOT / 'observabilidade/cloudformation/aplicado_20261028/import_template.json'
        before = historical.read_bytes()
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'alerts.json'
            with contextlib.redirect_stdout(io.StringIO()):
                alerts.main(['--output', str(target)])
            generated = target.read_bytes()
            self.assertEqual(json.loads(generated), alerts.build())
            with self.assertRaises(FileExistsError):
                alerts.main(['--output', str(target)])
            self.assertEqual(generated, target.read_bytes())
            outdir = Path(directory) / 'streaming'
            with contextlib.redirect_stdout(io.StringIO()):
                stream.main(['--bucket', 'outro-bucket-local', '--output-dir', str(outdir)])
            self.assertEqual(json.loads((outdir / 'streaming_stack.json').read_bytes()), stream.build(bucket_name='outro-bucket-local'))
            with self.assertRaises(FileExistsError):
                stream.main(['--bucket', 'outro-bucket-local', '--output-dir', str(outdir)])
        self.assertEqual(before, historical.read_bytes())


if __name__ == '__main__':
    unittest.main()
