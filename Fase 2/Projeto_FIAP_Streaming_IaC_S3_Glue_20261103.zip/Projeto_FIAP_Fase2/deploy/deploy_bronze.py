"""Publish a stopped Bronze Glue job. --dry-run is completely local; no job is run."""
import argparse
import hashlib
import json
from pathlib import Path
import re

try:
    from .configuration import add_environment_arguments, checked_session, resolve_role, validate_environment, valid_name, write_report
except ImportError:
    from configuration import add_environment_arguments, checked_session, resolve_role, validate_environment, valid_name, write_report

ROOT = Path(__file__).resolve().parents[1]
TABLES = 'alunos,municipio,uf,meta_alfabetizacao_brasil,meta_alfabetizacao_uf,meta_alfabetizacao_municipio,dicionario'


def parser_for_cli():
    parser = argparse.ArgumentParser(description=__doc__)
    add_environment_arguments(parser)
    parser.add_argument('--job-name', default='fiap-bronze-inep-batch')
    parser.add_argument('--script-file', default=str(ROOT / 'bronze/bronze_glue.py'))
    parser.add_argument('--connection-name', required=True, help='Existing Glue BigQuery connection; credentials stay in the connection')
    parser.add_argument('--parent-project', required=True, help='Existing GCP consumer project ID; does not enable billing')
    parser.add_argument('--source-dataset', default='basedosdados.br_inep_avaliacao_alfabetizacao')
    parser.add_argument('--output', help='Optional local JSON plan/result')
    return parser


def prepare(args):
    validate_environment(args)
    valid_name(args.connection_name, 'connection-name')
    if not re.fullmatch(r'[a-z][a-z0-9-]{4,61}[a-z0-9]', args.parent_project or ''):
        raise ValueError('Invalid parent-project')
    if not re.fullmatch(r'[a-z][a-z0-9-]{4,61}[a-z0-9]\.[A-Za-z_][A-Za-z0-9_]*', args.source_dataset or ''):
        raise ValueError('source-dataset must be project.dataset')
    script = Path(args.script_file).expanduser().resolve()
    digest = hashlib.sha256(script.read_bytes()).hexdigest()
    key = f'scripts/{args.job_name}/{digest}/bronze_glue.py'
    config = dict(
        Name=args.job_name,
        Description='Bronze INEP: sete tabelas BigQuery, historico imutavel por execucao e validacao de contagens.',
        Role=args.role_arn,
        Command={'Name': 'glueetl', 'ScriptLocation': f's3://{args.assets_bucket}/{key}', 'PythonVersion': '3'},
        Connections={'Connections': [args.connection_name]},
        DefaultArguments={
            '--BUCKET': args.bucket, '--PREFIX': 'bronze/inep', '--AUDIT_PREFIX': 'auditoria/bronze',
            '--CONNECTION_NAME': args.connection_name, '--PARENT_PROJECT': args.parent_project,
            '--SOURCE_DATASET': args.source_dataset, '--TABLES': TABLES,
            '--job-bookmark-option': 'job-bookmark-disable',
        },
        ExecutionProperty={'MaxConcurrentRuns': 1}, MaxRetries=0, Timeout=30,
        GlueVersion='5.1', WorkerType='G.1X', NumberOfWorkers=2, ExecutionClass='STANDARD',
        Tags={'Project': 'FIAP-TC-Fase2', 'Component': 'bronze-inep'},
    )
    return script, key, digest, config


def main(argv=None):
    parser = parser_for_cli()
    args = parser.parse_args(argv)
    try:
        script, key, digest, config = prepare(args)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    report = {'operation': 'DRY_RUN' if args.dry_run else 'create', 'cloud_calls': 0 if args.dry_run else None,
              'account': args.account_id, 'region': args.region, 'job_name': args.job_name,
              'script_sha256': digest, 'config': config, 'role_from_source_job': args.source_job,
              'run_started': False, 'prerequisites_checked_in_cloud': False}
    if args.dry_run:
        write_report(args.output, report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return report
    session = checked_session(args)
    glue = session.client('glue')
    try:
        glue.get_job(JobName=args.job_name)
    except glue.exceptions.EntityNotFoundException:
        pass
    else:
        raise RuntimeError(f'Job already exists; review it before changing: {args.job_name}')
    config['Role'] = resolve_role(args, glue)
    session.client('s3').upload_file(str(script), args.assets_bucket, key)
    result = glue.create_job(**config)
    report.update(job_name=result['Name'], script_uri=config['Command']['ScriptLocation'])
    write_report(args.output, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    main()
