"""Local configuration validation; importing this module never creates AWS clients."""
import json
from pathlib import Path
import re
from urllib.parse import urlsplit


def add_environment_arguments(parser, *, role=True):
    parser.add_argument('--account-id', required=True, help='Expected 12-digit AWS account; checked before mutation')
    parser.add_argument('--region', default='us-east-2')
    parser.add_argument('--bucket', required=True, help='Data bucket, already provisioned')
    parser.add_argument('--assets-bucket', required=True, help='Script/notebook bucket, already provisioned')
    if role:
        source = parser.add_mutually_exclusive_group(required=True)
        source.add_argument('--role-arn', help='Existing Glue execution role; no source job required')
        source.add_argument('--source-job', help='Optional existing job from which to read only the execution role')
    parser.add_argument('--dry-run', action='store_true', help='Validate and write a local plan without AWS clients/calls')


def valid_name(value, label):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_ .()/-]{1,200}', value):
        raise ValueError('Invalid ' + label)
    return value


def valid_bucket(value):
    if not re.fullmatch(r'[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]', value or '') or '..' in value or '.-' in value or '-.' in value or re.fullmatch(r'\d+\.\d+\.\d+\.\d+', value):
        raise ValueError('Invalid S3 bucket: ' + str(value))
    return value


def partition_for_region(region):
    if region.startswith('cn-'):
        return 'aws-cn'
    if region.startswith('us-gov-'):
        return 'aws-us-gov'
    return 'aws'


def validate_environment(args):
    if not re.fullmatch(r'\d{12}', args.account_id or ''):
        raise ValueError('account-id must have 12 digits')
    if not re.fullmatch(r'[a-z]{2}(?:-[a-z]+)+-\d+', args.region or ''):
        raise ValueError('Invalid region')
    valid_bucket(args.bucket)
    valid_bucket(args.assets_bucket)
    if getattr(args, 'role_arn', None):
        match = re.fullmatch(r'arn:(aws|aws-us-gov|aws-cn):iam::(\d{12}):role/([\w+=,.@/-]+)', args.role_arn)
        if not match or match.group(2) != args.account_id or match.group(1) != partition_for_region(args.region):
            raise ValueError('role-arn must identify a role in account-id and the selected region partition')
    if getattr(args, 'source_job', None):
        valid_name(args.source_job, 'source-job')
    if getattr(args, 'job_name', None):
        valid_name(args.job_name, 'job-name')


def validate_manifest(uri, bucket, source_layer):
    value = urlsplit(uri or '')
    if value.scheme != 's3' or value.netloc != bucket or not value.path.strip('/') or value.query or value.fragment:
        raise ValueError('Source manifest must be an s3:// URI in --bucket; specify --source-manifest-uri for the selected execution')
    if source_layer not in {'bronze', 'silver'}:
        raise ValueError('Source manifest layer must be bronze or silver')
    parts = value.path.lstrip('/').split('/')
    if (len(parts) < 4 or parts[:2] != ['auditoria', source_layer]
            or parts[-1] != 'manifest.json'
            or not re.fullmatch(r'run_id=[A-Za-z0-9_-]{1,200}', parts[-2])
            or sum(part.startswith('run_id=') for part in parts) != 1
            or any(part in {'.', '..'} or not re.fullmatch(r'[A-Za-z0-9_.=-]+', part) for part in parts)):
        raise ValueError('Select auditoria/' + source_layer + '/.../run_id=ID/manifest.json for the expected source layer')
    return uri


def load_defaults(path):
    data = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if not isinstance(data, dict) or any(not isinstance(k, str) or not k.startswith('--') or not isinstance(v, str) for k, v in data.items()):
        raise ValueError('defaults-json must map --ARGUMENT to string values')
    return data


def write_report(path, report):
    if path:
        output = Path(path).expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def checked_session(args):
    import boto3
    session = boto3.Session(region_name=args.region)
    actual = session.client('sts').get_caller_identity()['Account']
    if actual != args.account_id:
        raise RuntimeError(f'Wrong AWS account: expected {args.account_id}, got {actual}')
    return session


def resolve_role(args, glue):
    role = args.role_arn or glue.get_job(JobName=args.source_job)['Job']['Role']
    match = re.fullmatch(r'arn:(aws|aws-us-gov|aws-cn):iam::(\d{12}):role/([\w+=,.@/-]+)', role)
    if not match or match.group(2) != args.account_id or match.group(1) != partition_for_region(args.region):
        raise ValueError('Resolved execution role does not belong to account-id and the selected region partition')
    return role
