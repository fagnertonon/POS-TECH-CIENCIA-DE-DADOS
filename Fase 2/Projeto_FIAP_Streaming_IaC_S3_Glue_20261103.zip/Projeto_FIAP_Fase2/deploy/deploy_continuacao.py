"""Publish Silver/Gold assets and a stopped job. --dry-run makes no AWS calls."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

try:
    from .configuration import add_environment_arguments, checked_session, load_defaults, partition_for_region, resolve_role, validate_environment, validate_manifest, write_report
except ImportError:
    from configuration import add_environment_arguments, checked_session, load_defaults, partition_for_region, resolve_role, validate_environment, validate_manifest, write_report

ROOT = Path(__file__).resolve().parents[1]


def immutable_upload(s3, path, key, assets_bucket):
    from botocore.exceptions import ClientError
    content = Path(path).read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    try:
        s3.put_object(Bucket=assets_bucket, Key=key, Body=content, IfNoneMatch='*',
                      ServerSideEncryption='AES256', Metadata={'sha256': digest})
    except ClientError as exc:
        if exc.response['Error']['Code'] not in ('PreconditionFailed', '412'):
            raise
        body = s3.get_object(Bucket=assets_bucket, Key=key)['Body']
        try:
            existing = body.read()
        finally:
            body.close()
        if hashlib.sha256(existing).hexdigest() != digest:
            raise RuntimeError('An immutable asset exists with different content: ' + key)
    head = s3.head_object(Bucket=assets_bucket, Key=key)
    if head['ContentLength'] != len(content) or head.get('Metadata', {}).get('sha256') != digest:
        raise RuntimeError('Asset verification failed: ' + key)
    return {'uri': 's3://' + assets_bucket + '/' + key, 'sha256': digest, 'bytes': len(content)}


def parser_for_cli():
    parser = argparse.ArgumentParser(description=__doc__)
    add_environment_arguments(parser)
    parser.add_argument('--layer', choices=('silver', 'gold'), required=True)
    parser.add_argument('--directory', help='Defaults to the selected layer inside this repository')
    parser.add_argument('--defaults-json', help='Defaults to <directory>/job_defaults.json; original file is never edited')
    parser.add_argument('--source-manifest-uri', required=True, help='Explicit successful Bronze (Silver job) or Silver (Gold job) manifest in --bucket')
    parser.add_argument('--database-silver')
    parser.add_argument('--database-gold')
    parser.add_argument('--job-name', help='Defaults to fiap-<layer>-inep-batch')
    parser.add_argument('--output', required=True)
    parser.add_argument('--update-existing', action='store_true')
    return parser


def prepare(args):
    args.job_name = args.job_name or 'fiap-' + args.layer + '-inep-batch'
    validate_environment(args)
    root = Path(args.directory).expanduser().resolve() if args.directory else ROOT / args.layer
    defaults = load_defaults(args.defaults_json or root / 'job_defaults.json')
    bucket_key = '--BUCKET' if args.layer == 'silver' else '--S3_BUCKET'
    manifest_key = '--BRONZE_MANIFEST_URI' if args.layer == 'silver' else '--SILVER_MANIFEST_URI'
    defaults[bucket_key] = args.bucket
    source_layer = 'bronze' if args.layer == 'silver' else 'silver'
    defaults[manifest_key] = validate_manifest(args.source_manifest_uri, args.bucket, source_layer)
    for label, value in (('--DATABASE_SILVER', args.database_silver), ('--DATABASE_GOLD', args.database_gold)):
        if value:
            if not value.replace('_', '').isalnum() or not value.islower():
                raise ValueError('Catalog database must use lowercase letters, digits and underscores')
            defaults[label] = value
    defaults.update({'--job-bookmark-option': 'job-bookmark-disable', '--enable-glue-datacatalog': '',
                     '--enable-metrics': '', '--enable-continuous-cloudwatch-log': 'true',
                     '--enable-spark-ui': 'false', '--TempDir': 's3://' + args.assets_bucket + '/temporary/' + args.job_name + '/'})
    number = '02' if args.layer == 'silver' else '03'
    assets = {}
    for label, path in (('script', root / (args.layer + '_glue.py')),
                        ('original', root / (number + '_camada_' + args.layer + '_original.ipynb')),
                        ('notebook', root / (number + '_camada_' + args.layer + '_glue.ipynb'))):
        content = path.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        prefix = 'scripts' if label == 'script' else 'notebooks'
        key = prefix + '/' + args.job_name + '/' + digest + '/' + path.name
        assets[label] = {'uri': 's3://' + args.assets_bucket + '/' + key, 'sha256': digest,
                         'bytes': len(content), 'local_path': str(path), 'key': key}
    config = dict(
        Description='FIAP Fase 2: ' + args.layer + ' adaptada para Glue, historico e validacoes por execucao.',
        Role=args.role_arn, Command={'Name': 'glueetl', 'ScriptLocation': assets['script']['uri'], 'PythonVersion': '3'},
        DefaultArguments=defaults, ExecutionProperty={'MaxConcurrentRuns': 1}, MaxRetries=0, Timeout=15,
        GlueVersion='5.1', WorkerType='G.1X', NumberOfWorkers=2, ExecutionClass='STANDARD',
    )
    return assets, config


def main(argv=None):
    parser = parser_for_cli()
    args = parser.parse_args(argv)
    try:
        assets, config = prepare(args)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    report = {'verified_at_utc': datetime.now(timezone.utc).isoformat(), 'layer': args.layer,
              'job_name': args.job_name, 'operation': 'DRY_RUN', 'account': args.account_id, 'region': args.region,
              'assets': assets, 'config': config, 'role_from_source_job': args.source_job,
              'run_started': False, 'cloud_calls': 0, 'prerequisites_checked_in_cloud': False,
              'default_arguments': config['DefaultArguments']}
    if args.dry_run:
        write_report(args.output, report)
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return report
    session = checked_session(args)
    glue, s3 = session.client('glue'), session.client('s3')
    try:
        existing = glue.get_job(JobName=args.job_name)['Job']
    except glue.exceptions.EntityNotFoundException:
        existing = None
    if existing:
        if not args.update_existing:
            raise RuntimeError('Job exists; review before using --update-existing: ' + args.job_name)
        arn = 'arn:' + partition_for_region(args.region) + ':glue:' + args.region + ':' + args.account_id + ':job/' + args.job_name
        tags = glue.get_tags(ResourceArn=arn)['Tags']
        if tags.get('Project') != 'FIAP-TC-Fase2' or tags.get('Component') != args.layer + '-inep':
            raise RuntimeError('Refusing to change a job without the expected project tags')
        active = [run for run in glue.get_job_runs(JobName=args.job_name, MaxResults=10)['JobRuns']
                  if run['JobRunState'] in ('STARTING', 'RUNNING', 'STOPPING', 'WAITING')]
        if active:
            raise RuntimeError('An execution is active; refusing to change job')
    config['Role'] = resolve_role(args, glue)
    uploaded = {label: immutable_upload(s3, info['local_path'], info['key'], args.assets_bucket) for label, info in assets.items()}
    if existing:
        glue.update_job(JobName=args.job_name, JobUpdate=config)
        operation = 'updated'
    else:
        glue.create_job(Name=args.job_name, Tags={'Project': 'FIAP-TC-Fase2', 'Component': args.layer + '-inep'}, **config)
        operation = 'created'
    saved = glue.get_job(JobName=args.job_name)['Job']
    for key in ('Role', 'Command', 'MaxRetries', 'Timeout', 'GlueVersion', 'WorkerType', 'NumberOfWorkers'):
        if saved[key] != config[key]:
            raise RuntimeError('Saved configuration mismatch: ' + key)
    report.update(operation=operation, assets=uploaded, cloud_calls=None,
                  script_uri=uploaded['script']['uri'], original_uri=uploaded['original']['uri'],
                  notebook_uri=uploaded['notebook']['uri'], workers=2, worker_type='G.1X',
                  timeout_minutes=15, max_retries=0)
    write_report(args.output, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return report


if __name__ == '__main__':
    main()
