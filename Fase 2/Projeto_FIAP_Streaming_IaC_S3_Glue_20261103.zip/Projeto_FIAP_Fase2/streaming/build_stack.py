"""Generate a local template; never deploy or overwrite a historical template.

The Python API and CLI require a bucket explicitly. Historical baseline tests
read that bucket from their fixture, rather than selecting a deployment target.
The reusable CLI also requires a new output directory explicitly.
"""
import argparse
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
FUNCTION = 'fiap-inep-streaming-consumer'
QUEUE = 'fiap-inep-streaming'
ROLE = 'fiap-lambda-inep-streaming'
PIPELINE = 'fiap-inep-streaming'


def sub(value):
    return {'Fn::Sub': value}


def attr(resource, key):
    return {'Fn::GetAtt': [resource, key]}


def build(*, bucket_name, function_name=FUNCTION,
          queue_name=QUEUE, role_name=ROLE, pipeline=PIPELINE, alert_topic_arn=None):
    for label, value, limit in [('function', function_name, 64), ('queue', queue_name, 75),
                                ('role', role_name, 64), ('pipeline', pipeline, 200)]:
        if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,' + str(limit) + '}', value):
            raise ValueError('Invalid ' + label + ' name')
    if (not isinstance(bucket_name, str)
            or not re.fullmatch(r'[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]', bucket_name)
            or any(part in bucket_name for part in ('..', '.-', '-.'))
            or re.fullmatch(r'\d+\.\d+\.\d+\.\d+', bucket_name)):
        raise ValueError('Invalid bucket name')
    if alert_topic_arn is not None and not re.fullmatch(r'arn:(aws|aws-cn|aws-us-gov):sns:[a-z0-9-]+:[0-9]{12}:[A-Za-z0-9_-]+', alert_topic_arn):
        raise ValueError('Invalid SNS topic ARN')
    source = (ROOT / 'lambda_function.py').read_text(encoding='utf-8')
    if pipeline != PIPELINE:
        assignment = 'PIPELINE = "fiap-inep-streaming"'
        if source.count(assignment) != 1:
            raise ValueError('Lambda pipeline assignment changed; review before generating a custom template')
        # Render only the new inline artifact; keep the historical source intact.
        source = source.replace(assignment, 'PIPELINE = ' + repr(pipeline), 1)
    bucket = {'Ref': 'BucketName'}
    s3_paths = [sub('arn:${AWS::Partition}:s3:::${BucketName}/' + prefix + '/*') for prefix in (
        'bronze/inep_streaming', 'silver/inep_streaming/entity=alunos',
        'gold/inep_streaming/contribuicoes', 'auditoria/streaming/idempotency',
        'auditoria/streaming/processed')]
    resources = {
        'DeadLetterQueue': {'Type': 'AWS::SQS::Queue', 'Properties': {
            'QueueName': queue_name + '-dlq', 'MessageRetentionPeriod': 1209600,
            'SqsManagedSseEnabled': True,
            'RedriveAllowPolicy': {'redrivePermission': 'byQueue', 'sourceQueueArns': [sub('arn:${AWS::Partition}:sqs:${AWS::Region}:${AWS::AccountId}:' + queue_name)]},
            'Tags': [{'Key': 'Project', 'Value': 'FIAP-TC-Fase2'}],
        }},
        'SourceQueue': {'Type': 'AWS::SQS::Queue', 'Properties': {
            'QueueName': queue_name, 'VisibilityTimeout': 60, 'ReceiveMessageWaitTimeSeconds': 20,
            'MessageRetentionPeriod': 345600, 'SqsManagedSseEnabled': True,
            'RedrivePolicy': {'deadLetterTargetArn': attr('DeadLetterQueue', 'Arn'), 'maxReceiveCount': 5},
            'Tags': [{'Key': 'Project', 'Value': 'FIAP-TC-Fase2'}],
        }},
        'ConsumerLogs': {'Type': 'AWS::Logs::LogGroup', 'DeletionPolicy': 'Retain', 'UpdateReplacePolicy': 'Retain', 'Properties': {
            'LogGroupName': '/aws/lambda/' + function_name, 'RetentionInDays': 14,
        }},
        'ConsumerRole': {'Type': 'AWS::IAM::Role', 'Properties': {
            'RoleName': role_name,
            'AssumeRolePolicyDocument': {'Version': '2012-10-17', 'Statement': [{
                'Effect': 'Allow', 'Principal': {'Service': 'lambda.amazonaws.com'}, 'Action': 'sts:AssumeRole',
            }]},
            'Policies': [{'PolicyName': 'StreamingScopedAccess', 'PolicyDocument': {
                'Version': '2012-10-17', 'Statement': [
                    {'Sid': 'PollOnlyTheStreamingQueue', 'Effect': 'Allow', 'Action': ['sqs:ReceiveMessage', 'sqs:DeleteMessage', 'sqs:GetQueueAttributes'], 'Resource': attr('SourceQueue', 'Arn')},
                    {'Sid': 'PersistOnlyStreamingObjects', 'Effect': 'Allow', 'Action': ['s3:GetObject', 's3:PutObject'], 'Resource': s3_paths},
                    {'Sid': 'WriteOnlyTheConsumerLogs', 'Effect': 'Allow', 'Action': ['logs:CreateLogStream', 'logs:PutLogEvents'],
                     'Resource': sub('arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:log-group:/aws/lambda/' + function_name + ':*')},
                ],
            }}],
            'Tags': [{'Key': 'Project', 'Value': 'FIAP-TC-Fase2'}],
        }},
        'ConsumerFunction': {'Type': 'AWS::Lambda::Function', 'DependsOn': 'ConsumerLogs', 'Properties': {
            'FunctionName': function_name, 'Runtime': 'python3.12', 'Handler': 'index.lambda_handler',
            'Role': attr('ConsumerRole', 'Arn'), 'Timeout': 10, 'MemorySize': 256,
            'ReservedConcurrentExecutions': 2,
            'Description': 'Simulacao INEP v2: SQS para Bronze, Silver e Gold isoladas; idempotencia e qualidade.',
            'Code': {'ZipFile': source},
            'Environment': {'Variables': {'BUCKET': bucket, 'PREFIX': 'bronze/inep_streaming',
                'IDEMPOTENCY_PREFIX': 'auditoria/streaming/idempotency', 'ALLOWED_ENTITIES': 'alunos',
                'SILVER_PREFIX': 'silver/inep_streaming', 'GOLD_PREFIX': 'gold/inep_streaming',
                'PROCESSED_PREFIX': 'auditoria/streaming/processed'}},
            'Tags': [{'Key': 'Project', 'Value': 'FIAP-TC-Fase2'}],
        }},
        'QueueConsumerMapping': {'Type': 'AWS::Lambda::EventSourceMapping', 'Properties': {
            'FunctionName': {'Ref': 'ConsumerFunction'}, 'EventSourceArn': attr('SourceQueue', 'Arn'),
            'BatchSize': 5, 'MaximumBatchingWindowInSeconds': 0,
            'FunctionResponseTypes': ['ReportBatchItemFailures'],
            'ScalingConfig': {'MaximumConcurrency': 2}, 'Enabled': True,
        }},
    }
    alarm_common = {'ComparisonOperator': 'GreaterThanOrEqualToThreshold', 'EvaluationPeriods': 1,
                    'DatapointsToAlarm': 1, 'Period': 60, 'Statistic': 'Sum', 'TreatMissingData': 'notBreaching'}
    for logical, suffix, namespace, metric, dimensions, threshold, statistic, description in [
        ('DeadLetterAlarm', 'dlq', 'AWS/SQS', 'ApproximateNumberOfMessagesVisible', [{'Name': 'QueueName', 'Value': queue_name + '-dlq'}], 1, 'Maximum', 'Mensagem na DLQ; revisar erros no CloudWatch e corrigir antes do redrive. Alerta visivel no console, sem e-mail configurado.'),
        ('RejectedEventAlarm', 'rejected', 'FIAP/Streaming', 'Failed', [{'Name': 'Pipeline', 'Value': pipeline}], 1, 'Sum', 'Evento rejeitado pelo consumidor; verificar logs e DLQ. Alerta visivel no console.'),
        ('QueueAgeAlarm', 'age', 'AWS/SQS', 'ApproximateAgeOfOldestMessage', [{'Name': 'QueueName', 'Value': queue_name}], 120, 'Maximum', 'Atraso de processamento maior ou igual a 120 segundos; revisar Lambda e fila.'),
    ]:
        resources[logical] = {'Type': 'AWS::CloudWatch::Alarm', 'Properties': {
            **alarm_common, 'AlarmName': pipeline + '-' + suffix, 'AlarmDescription': description,
            'Namespace': namespace, 'MetricName': metric, 'Dimensions': dimensions,
            'Threshold': threshold, 'Statistic': statistic,
        }}
    template = {
        'AWSTemplateFormatVersion': '2010-09-09',
        'Description': 'FIAP Fase2 streaming simulacao Bronze-Silver-Gold: SQS/Lambda/S3, role restrita e DLQ.',
        'Parameters': {'BucketName': {'Type': 'String', 'Default': bucket_name}},
        'Resources': resources,
        'Outputs': {
            'QueueUrl': {'Value': {'Ref': 'SourceQueue'}}, 'QueueArn': {'Value': attr('SourceQueue', 'Arn')},
            'DeadLetterQueueUrl': {'Value': {'Ref': 'DeadLetterQueue'}},
            'FunctionName': {'Value': {'Ref': 'ConsumerFunction'}}, 'FunctionArn': {'Value': attr('ConsumerFunction', 'Arn')},
            'ExecutionRoleArn': {'Value': attr('ConsumerRole', 'Arn')},
            'EventSourceMappingUuid': {'Value': {'Ref': 'QueueConsumerMapping'}},
            'LogGroup': {'Value': {'Ref': 'ConsumerLogs'}},
        },
    }


    if alert_topic_arn is not None:
        template['Parameters']['AlertTopicArn'] = {'Type': 'String', 'Default': alert_topic_arn}
        for logical in ('DeadLetterAlarm', 'RejectedEventAlarm', 'QueueAgeAlarm'):
            props = template['Resources'][logical]['Properties']
            props.update(ActionsEnabled=True, AlarmActions=[{'Ref': 'AlertTopicArn'}], OKActions=[])
            props['AlarmDescription'] = props['AlarmDescription'].replace(' Alerta visivel no console, sem e-mail configurado.', '').replace(' Alerta visivel no console.', '')
    return template


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bucket', required=True)
    parser.add_argument('--function-name', default=FUNCTION)
    parser.add_argument('--queue-name', default=QUEUE)
    parser.add_argument('--role-name', default=ROLE)
    parser.add_argument('--pipeline', default=PIPELINE)
    parser.add_argument('--alert-topic-arn')
    parser.add_argument('--output-dir', required=True, type=Path, help='New local directory; historical files are never overwritten')
    args = parser.parse_args(argv)
    template = build(bucket_name=args.bucket, function_name=args.function_name,
                     queue_name=args.queue_name, role_name=args.role_name,
                     pipeline=args.pipeline, alert_topic_arn=args.alert_topic_arn)
    args.output_dir.mkdir(parents=True, exist_ok=False)
    for name, value in [('streaming_stack.json', template), ('iam_role_review.json', template['Resources']['ConsumerRole']['Properties'])]:
        (args.output_dir / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('LOCAL_ONLY: templates generated; no AWS calls: ' + str(args.output_dir))


if __name__ == '__main__':
    main()
