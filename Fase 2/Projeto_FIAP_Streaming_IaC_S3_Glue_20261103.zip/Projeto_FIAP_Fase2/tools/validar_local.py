"""Run the release's selected offline tests with network connections blocked.

Use a NEW output directory outside the project. This never discovers archived
scripts under evidencias/ and never invokes deploys, extracts or real notifications.
It uses the current Python interpreter; install requirements separately.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SUITES = (
    ('silver', 'silver', 'test_*.py'),
    ('gold', 'gold', 'test_*.py'),
    ('streaming', 'streaming', 'test_*.py'),
    ('notificacoes_com_mocks', 'observabilidade/scripts', 'test_configure_notifications.py'),
    ('configuracao_integridade_notebooks_templates', 'tests', 'test_*.py'),
    ('finops_registros_locais', 'finops/revisao_registros_20261028', 'test_auditar_logs_local.py'),
)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args(argv)
    out = args.output_dir.resolve()
    if out.is_relative_to(ROOT):
        parser.error('--output-dir must be outside the verified project tree')
    out.mkdir(parents=True, exist_ok=False)
    temporary = out / 'temp'
    temporary.mkdir()
    guard = out / 'network_guard'
    guard.mkdir()
    network_log = out / 'network_attempts.txt'
    (guard / 'sitecustomize.py').write_text('''import os, socket
def blocked(*args, **kwargs):
    with open(os.environ['FIAP_OFFLINE_NETWORK_LOG'], 'a', encoding='utf-8') as f:
        f.write('Blocked network connection attempt\\n')
    raise RuntimeError('Network is disabled for the local FIAP test suite')
socket.socket.connect = blocked
socket.socket.connect_ex = blocked
socket.create_connection = blocked
''', encoding='utf-8')
    env = dict(os.environ)
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(guard),
               AWS_ACCESS_KEY_ID='offline-test-key', AWS_SECRET_ACCESS_KEY='offline-test-secret',
               AWS_SESSION_TOKEN='offline-test-token', AWS_EC2_METADATA_DISABLED='true',
               AWS_REGION='us-east-2', AWS_DEFAULT_REGION='us-east-2', AWS_MAX_ATTEMPTS='1',
               TEMP=str(temporary), TMP=str(temporary),
               FIAP_OFFLINE_NETWORK_LOG=str(network_log))
    results = []
    for label, directory, pattern in SUITES:
        command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', directory, '-p', pattern]
        completed = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True,
                                   encoding='utf-8', errors='replace', timeout=180)
        output = completed.stdout + completed.stderr
        (out / (label + '.txt')).write_text(output, encoding='utf-8')
        match = re.search(r'Ran (\d+) tests? in ', output)
        skipped = re.search(r'OK \(skipped=(\d+)\)', output)
        count = int(match.group(1)) if match else 0
        results.append({'suite': label, 'returncode': completed.returncode, 'tests': count,
                        'skipped': int(skipped.group(1)) if skipped else 0, 'log': label + '.txt'})
        print(f'{label}: exit={completed.returncode}; tests={count}', flush=True)
    attempts = len(network_log.read_text(encoding='utf-8').splitlines()) if network_log.exists() else 0
    report = {
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'CURRENT_RELEASE_OFFLINE_TESTS', 'python': sys.version,
        'network_guard': True, 'network_connection_attempts': attempts,
        'aws_gcp_deploy_or_extraction_started': False,
        'total_tests': sum(item['tests'] for item in results),
        'skipped_tests': sum(item['skipped'] for item in results),
        'status': 'PASSED' if all(item['returncode'] == 0 and item['tests'] > 0 for item in results) and attempts == 0 else 'FAILED',
        'results': results,
        'historical_migration_tests': {
            'included_in_current_suite': False,
            'reason': 'Archived hash-bound plan uses originals; preserved public evidence is anonymized. See INTEGRIDADE_RELEASE.txt.',
            'known_review_result': '6 passed and 1 error after historical email anonymization; not a deployed pipeline failure',
        },
        'limitations': ['No Spark/Glue execution', 'No deployment or current cloud state verification',
                        'Optional pandas analysis not executed', 'Real symlink test may be skipped without OS privilege; mocked rejection is tested'],
    }
    (out / 'relatorio_testes.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return 0 if report['status'] == 'PASSED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
