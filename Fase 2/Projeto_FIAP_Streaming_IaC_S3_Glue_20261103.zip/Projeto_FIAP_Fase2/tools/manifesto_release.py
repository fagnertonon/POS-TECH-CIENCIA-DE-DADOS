"""Manifesto SHA256 estrito: sem rede, sem modificar dados ou manifesto historico.

Gerar ao terminar as edicoes: python -B tools/manifesto_release.py --gerar
Sobrescrita requer --substituir. O verificador nunca reescreve hashes.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile

DEFAULT_MANIFEST = "SHA256_Release.json"
ROOT_METADATA = [".git"]
RAIZ = Path(__file__).resolve().parent.parent
SCHEMA_KEYS = {"schema_version", "hash_algorithm", "release", "self_excluded", "ignored_root_metadata", "files"}


def _unique_object(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError("Chave JSON repetida: " + str(key))
        out[key] = value
    return out


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_unique_object)


def safe_relative(name: str) -> str:
    if not isinstance(name, str) or not name or "\\" in name or ":" in name or "\x00" in name:
        raise ValueError("Caminho invalido no manifesto")
    path = PurePosixPath(name)
    if path.is_absolute() or str(path) != name or any(p in ("", ".", "..") for p in name.split("/")):
        raise ValueError("Caminho fora do formato relativo seguro: " + name)
    return name


def manifest_location(root: Path, manifest=DEFAULT_MANIFEST) -> tuple[Path, str]:
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise ValueError("A raiz precisa ser um diretorio")
    candidate = Path(manifest)
    if not candidate.is_absolute():
        safe_relative(str(manifest).replace(os.sep, "/"))
        candidate = root / candidate
    if candidate.is_symlink():
        raise ValueError("O manifesto nao pode ser symlink")
    try:
        relative = candidate.resolve().relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError("O manifesto deve ficar dentro da raiz") from exc
    safe_relative(relative)
    if relative.split("/", 1)[0] == ".git":
        raise ValueError("Manifesto nao pode ficar no metadado .git")
    return candidate, relative


def inventory(root: Path, manifest_relative: str) -> dict:
    root = root.resolve(strict=True)
    manifest_relative = safe_relative(manifest_relative)
    found = {}
    folded = set()
    def walk_error(error):
        raise error  # Nao certificar silenciosamente um diretorio ilegivel.
    for current, dirs, files in os.walk(root, followlinks=False, onerror=walk_error):
        directory = Path(current)
        if directory == root:
            dirs[:] = [d for d in dirs if d != ".git"]
            files = [f for f in files if f != ".git"]
        for child in dirs:
            if (directory / child).is_symlink():
                raise ValueError("Symlink de diretorio nao permitido: " + str((directory / child).relative_to(root)))
        for name in sorted(files):
            path = directory / name
            relative = path.relative_to(root).as_posix()
            if relative == manifest_relative:
                if path.is_symlink():
                    raise ValueError("O manifesto nao pode ser symlink")
                continue
            safe_relative(relative)
            if path.is_symlink() or not path.is_file():
                raise ValueError("Arquivo regular exigido: " + relative)
            if relative.casefold() in folded:
                raise ValueError("Caminhos ambiguos por maiusculas/minusculas: " + relative)
            folded.add(relative.casefold())
            raw = path.read_bytes()
            found[relative] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    return dict(sorted(found.items()))


def validate_entries(entries: dict, manifest_relative: str | None = None) -> None:
    if not isinstance(entries, dict) or not entries:
        raise ValueError("Manifesto vazio ou files invalido")
    folded = set()
    for name, info in entries.items():
        safe_relative(name)
        if manifest_relative and name.casefold() == manifest_relative.casefold():
            raise ValueError("Hash circular: manifesto nao pode incluir a si proprio")
        if name.split("/", 1)[0] == ".git":
            raise ValueError("Manifesto nao pode incluir metadado .git da raiz")
        if name.casefold() in folded:
            raise ValueError("Caminhos duplicados por maiusculas/minusculas")
        folded.add(name.casefold())
        if not isinstance(info, dict) or set(info) != {"bytes", "sha256"}:
            raise ValueError("Entrada invalida: " + name)
        if type(info["bytes"]) is not int or info["bytes"] < 0:
            raise ValueError("Tamanho invalido: " + name)
        if not isinstance(info["sha256"], str) or re.fullmatch(r"[0-9a-f]{64}", info["sha256"]) is None:
            raise ValueError("SHA256 invalido: " + name)


def compare(expected: dict, actual: dict) -> dict:
    missing = sorted(set(expected) - set(actual))
    new = sorted(set(actual) - set(expected))
    changed = sorted(name for name in set(expected) & set(actual) if expected[name] != actual[name])
    return {"ok": not (missing or new or changed), "matched": len(set(expected) & set(actual)) - len(changed),
            "missing": missing, "changed": changed, "new": new}


def build(root: Path, manifest=DEFAULT_MANIFEST, version="revisao-local-20261028") -> dict:
    _, relative = manifest_location(root, manifest)
    if not isinstance(version, str) or not version.strip():
        raise ValueError("Versao da release vazia")
    files = inventory(root, relative)
    validate_entries(files, relative)
    return {"schema_version": 1, "hash_algorithm": "sha256", "release": version,
            "self_excluded": relative, "ignored_root_metadata": ROOT_METADATA[:], "files": files}


def write(root: Path, manifest=DEFAULT_MANIFEST, version="revisao-local-20261028", replace=False) -> Path:
    path, _ = manifest_location(root, manifest)
    if path.exists() and not replace:
        raise ValueError("Manifesto ja existe; use --substituir somente apos revisar as alteracoes")
    if path.name.casefold() == "sha256_arquivos.json":
        raise ValueError("O manifesto historico nao pode ser sobrescrito por esta ferramenta")
    if not path.parent.is_dir():
        raise ValueError("Diretorio do manifesto inexistente")
    content = build(root, manifest, version)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", dir=path.parent, prefix=".release-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(content, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        temporary.replace(path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return path


def verify(root: Path, manifest=DEFAULT_MANIFEST) -> dict:
    path, relative = manifest_location(root, manifest)
    document = read_json(path)
    if not isinstance(document, dict) or set(document) != SCHEMA_KEYS:
        raise ValueError("Esquema do manifesto da release invalido")
    if document["schema_version"] != 1 or type(document["schema_version"]) is not int or document["hash_algorithm"] != "sha256":
        raise ValueError("Versao ou algoritmo de manifesto invalido")
    if document["self_excluded"] != relative or document["ignored_root_metadata"] != ROOT_METADATA:
        raise ValueError("Exclusoes diferentes das duas exclusoes fixas permitidas")
    if not isinstance(document["release"], str) or not document["release"].strip():
        raise ValueError("Versao da release vazia")
    validate_entries(document["files"], relative)
    result = compare(document["files"], inventory(root, relative))
    result.update(mode="release", manifest=relative, release=document["release"])
    return result


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raiz", type=Path, default=RAIZ)
    parser.add_argument("--manifesto", default=DEFAULT_MANIFEST)
    parser.add_argument("--versao", default="revisao-local-20261028")
    parser.add_argument("--gerar", action="store_true")
    parser.add_argument("--substituir", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.substituir and not args.gerar:
            raise ValueError("--substituir exige --gerar")
        if args.gerar:
            path = write(args.raiz, args.manifesto, args.versao, args.substituir)
            result = verify(args.raiz, args.manifesto)
            print("Manifesto gerado:", path)
        else:
            result = verify(args.raiz, args.manifesto)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 1
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print("ERRO DE MANIFESTO: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
