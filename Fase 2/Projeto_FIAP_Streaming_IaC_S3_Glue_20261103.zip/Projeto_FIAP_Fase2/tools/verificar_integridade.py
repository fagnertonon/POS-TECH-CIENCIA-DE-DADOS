"""Valida SHA256_Release.json estritamente; --historico compara o pacote antigo.

Arquivo alterado, ausente ou novo causa exit 1; erro de formato/configuracao,
exit 2. Somente o proprio manifesto e .git na raiz ficam fora da release.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import manifesto_release as release
else:
    from . import manifesto_release as release
RAIZ = Path(__file__).resolve().parent.parent


def historical_comparison(root: Path) -> dict:
    historic = release.read_json(root / "SHA256_Arquivos.json")
    release.validate_entries(historic)
    rules = []
    ignore = root / ".gitignore"
    if ignore.is_file():
        for line in ignore.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and not any(c in line for c in "*?[!"):
                rules.append(line.lstrip("/"))
    excluded = {p for p in historic if any(p == r or (r.endswith("/") and p.startswith(r)) for r in rules)}
    expected = {p: info for p, info in historic.items() if p not in excluded}
    actual = release.inventory(root, "SHA256_Arquivos.json")
    result = release.compare(expected, actual)
    result.update(mode="historico", manifest="SHA256_Arquivos.json", excluded=sorted(excluded))
    return result


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raiz", type=Path, default=RAIZ)
    parser.add_argument("--manifesto", default=release.DEFAULT_MANIFEST)
    parser.add_argument("--historico", action="store_true", help="Diferencas documentadas ainda retornam 1")
    parser.add_argument("--detalhe", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.historico and args.manifesto != release.DEFAULT_MANIFEST:
            raise ValueError("--manifesto nao se aplica ao modo --historico")
        root = args.raiz.resolve(strict=True)
        result = historical_comparison(root) if args.historico else release.verify(root, args.manifesto)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print("ERRO DE INTEGRIDADE: " + str(exc), file=sys.stderr)
        return 2
    print("modo:", result["mode"])
    print("manifesto:", result["manifest"])
    print("conferem:", result["matched"])
    print("ausentes:", len(result["missing"]))
    print("alterados:", len(result["changed"]))
    print("novos:", len(result["new"]))
    if args.historico:
        print("exclusoes historicas documentadas:", len(result["excluded"]))
        print("Este modo NAO valida a release atual nem reescreve hashes antigos.")
    if args.detalhe:
        for name in result.get("excluded", []):
            print("EXCLUIDO_HISTORICO", name)
        for label, key in (("AUSENTE", "missing"), ("ALTERADO", "changed"), ("NOVO", "new")):
            for name in result[key]:
                print(label, name)
    if result["ok"]:
        print("PASS: arquivos conferem com o manifesto selecionado.")
        return 0
    print("DIVERGENTE: arquivos nao conferem com o manifesto selecionado.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
