"""Offline guards for portable deployment plans; every AWS boundary is mocked."""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from deploy import configuration, deploy_bronze, deploy_continuacao, verify_continuacao

ACCOUNT = '123456789012'
ROLE = 'arn:aws:iam::123456789012:role/projeto/GlueExecution'
COMMON = ['--account-id', ACCOUNT, '--bucket', 'dados-fiap-exemplo', '--assets-bucket', 'assets-fiap-exemplo', '--role-arn', ROLE]


class PortableDeploymentTests(unittest.TestCase):
    def invoke(self, module, arguments):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return module.main(arguments)

    def test_bronze_explicit_role_dry_run_is_local_and_portable(self):
        with patch.object(deploy_bronze, 'checked_session', side_effect=AssertionError('AWS forbidden')) as boundary:
            report = self.invoke(deploy_bronze, COMMON + ['--connection-name', 'Conexao BigQuery', '--parent-project', 'projeto-exemplo-123', '--job-name', 'outro-bronze', '--dry-run'])
        boundary.assert_not_called()
        self.assertEqual(report['cloud_calls'], 0)
        self.assertFalse(report['run_started'])
        self.assertEqual(report['config']['Role'], ROLE)
        self.assertEqual(report['config']['Connections']['Connections'], ['Conexao BigQuery'])
        self.assertEqual(report['config']['DefaultArguments']['--BUCKET'], 'dados-fiap-exemplo')
        self.assertIn('s3://assets-fiap-exemplo/scripts/outro-bronze/', report['config']['Command']['ScriptLocation'])

    def test_optional_source_job_dry_run_does_not_read_job(self):
        source = COMMON[:-2] + ['--source-job', 'job-opcional']
        with patch.object(deploy_bronze, 'checked_session', side_effect=AssertionError('AWS forbidden')):
            report = self.invoke(deploy_bronze, source + ['--connection-name', 'BigQuery', '--parent-project', 'projeto-exemplo-123', '--dry-run'])
        self.assertEqual(report['role_from_source_job'], 'job-opcional')
        self.assertIsNone(report['config']['Role'])
        self.assertFalse(report['prerequisites_checked_in_cloud'])

    def test_explicit_role_never_reads_existing_job(self):
        glue = MagicMock()
        args = types.SimpleNamespace(role_arn=ROLE, source_job=None, account_id=ACCOUNT, region='us-east-2')
        self.assertEqual(configuration.resolve_role(args, glue), ROLE)
        glue.get_job.assert_not_called()

    def test_optional_source_job_role_must_also_match_account(self):
        glue = MagicMock()
        glue.get_job.return_value = {'Job': {'Role': 'arn:aws:iam::999999999999:role/OtherRole'}}
        args = types.SimpleNamespace(role_arn=None, source_job='job-opcional', account_id=ACCOUNT, region='us-east-2')
        with self.assertRaises(ValueError):
            configuration.resolve_role(args, glue)

    def test_silver_overrides_environment_without_modifying_defaults(self):
        original = ROOT / 'silver/job_defaults.json'
        before = original.read_bytes()
        with tempfile.TemporaryDirectory() as tmp, patch.object(deploy_continuacao, 'checked_session', side_effect=AssertionError('AWS forbidden')):
            report = self.invoke(deploy_continuacao, COMMON + ['--layer', 'silver', '--output', str(Path(tmp) / 'plan.json'), '--source-manifest-uri', 's3://dados-fiap-exemplo/auditoria/bronze/run_id=novo/manifest.json', '--database-silver', 'outro_silver', '--dry-run'])
        self.assertEqual(original.read_bytes(), before)
        self.assertEqual(report['default_arguments']['--BUCKET'], 'dados-fiap-exemplo')
        self.assertEqual(report['default_arguments']['--DATABASE_SILVER'], 'outro_silver')
        self.assertIn('s3://assets-fiap-exemplo/temporary/', report['default_arguments']['--TempDir'])
        self.assertEqual(report['config']['NumberOfWorkers'], 2)

    def test_gold_uses_selected_silver_manifest(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(deploy_continuacao, 'checked_session', side_effect=AssertionError('AWS forbidden')):
            manifest = 's3://dados-fiap-exemplo/auditoria/silver/run_id=novo/manifest.json'
            report = self.invoke(deploy_continuacao, COMMON + ['--layer', 'gold', '--output', str(Path(tmp) / 'plan.json'), '--source-manifest-uri', manifest, '--job-name', 'outro-gold', '--dry-run'])
        self.assertEqual(report['job_name'], 'outro-gold')
        self.assertEqual(report['default_arguments']['--SILVER_MANIFEST_URI'], manifest)
        self.assertEqual(report['default_arguments']['--S3_BUCKET'], 'dados-fiap-exemplo')
        self.assertEqual(len(report['assets']), 3)

    def test_foreign_manifest_is_rejected_before_any_client(self):
        with patch.object(deploy_continuacao, 'checked_session') as boundary:
            with self.assertRaises(SystemExit):
                self.invoke(deploy_continuacao, COMMON + ['--layer', 'gold', '--source-manifest-uri', 's3://outro-bucket/auditoria/silver/run_id=x/manifest.json', '--output', 'not-written.json'])
        boundary.assert_not_called()

    def test_cli_requires_explicit_manifest_even_in_historical_bucket(self):
        arguments = COMMON.copy()
        arguments[arguments.index('--bucket') + 1] = 'fiap-tc-fase2-2026'
        with patch.object(deploy_continuacao, 'checked_session') as boundary:
            with self.assertRaises(SystemExit):
                self.invoke(deploy_continuacao, arguments + ['--layer', 'gold', '--dry-run', '--output', 'not-written.json'])
        boundary.assert_not_called()

    def test_role_in_other_account_is_rejected_before_any_client(self):
        arguments = COMMON[:-1] + ['arn:aws:iam::999999999999:role/GlueExecution']
        with patch.object(deploy_bronze, 'checked_session') as boundary:
            with self.assertRaises(SystemExit):
                self.invoke(deploy_bronze, arguments + ['--connection-name', 'BigQuery', '--parent-project', 'projeto-exemplo-123'])
        boundary.assert_not_called()

    def test_invalid_project_is_rejected_before_any_client(self):
        with patch.object(deploy_bronze, 'checked_session') as boundary:
            with self.assertRaises(SystemExit):
                self.invoke(deploy_bronze, COMMON + ['--connection-name', 'BigQuery', '--parent-project', 'INVALID!'])
        boundary.assert_not_called()

    def test_missing_local_asset_is_rejected_before_any_client(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(deploy_continuacao, 'checked_session') as boundary:
            defaults = Path(tmp) / 'defaults.json'
            defaults.write_text('{}', encoding='utf-8')
            with self.assertRaises(SystemExit):
                self.invoke(deploy_continuacao, COMMON + ['--layer', 'silver', '--directory', tmp, '--defaults-json', str(defaults), '--source-manifest-uri', 's3://dados-fiap-exemplo/auditoria/bronze/run_id=x/manifest.json', '--output', str(Path(tmp) / 'output.json')])
        boundary.assert_not_called()

    def test_directory_cannot_be_used_as_publication_manifest(self):
        with self.assertRaises(ValueError):
            configuration.validate_manifest('s3://dados-fiap-exemplo/silver/inep/', 'dados-fiap-exemplo', 'bronze')

    def test_checked_session_refuses_wrong_account_before_other_services(self):
        session = MagicMock()
        session.client.return_value.get_caller_identity.return_value = {'Account': '999999999999'}
        fake = types.SimpleNamespace(Session=MagicMock(return_value=session))
        with patch.dict(sys.modules, {'boto3': fake}):
            with self.assertRaises(RuntimeError):
                configuration.checked_session(types.SimpleNamespace(region='us-east-2', account_id=ACCOUNT))
        session.client.assert_called_once_with('sts')

    def test_existing_job_without_update_permission_does_not_upload(self):
        session = MagicMock()
        glue, s3 = MagicMock(), MagicMock()
        glue.exceptions.EntityNotFoundException = type('NotFound', (Exception,), {})
        glue.get_job.return_value = {'Job': {'Role': ROLE}}
        session.client.side_effect = lambda service: {'glue': glue, 's3': s3}[service]
        with tempfile.TemporaryDirectory() as tmp, patch.object(deploy_continuacao, 'checked_session', return_value=session):
            with self.assertRaisesRegex(RuntimeError, 'Job exists'):
                self.invoke(deploy_continuacao, COMMON + ['--layer', 'silver', '--source-manifest-uri', 's3://dados-fiap-exemplo/auditoria/bronze/run_id=x/manifest.json', '--output', str(Path(tmp) / 'output.json')])
        s3.put_object.assert_not_called()
        glue.update_job.assert_not_called()
        glue.create_job.assert_not_called()

    def test_observer_dry_run_does_not_inspect_cloud(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(verify_continuacao, 'inspect', side_effect=AssertionError('AWS forbidden')) as boundary:
            path = Path(tmp) / 'observer.json'
            report = self.invoke(verify_continuacao, ['--account-id', ACCOUNT, '--bucket', 'dados-fiap-exemplo', '--layer', 'gold', '--run-id', 'jr_exemplo', '--output', str(path), '--dry-run'])
            self.assertEqual(json.loads(path.read_text(encoding='utf-8'))['verification_status'], 'NOT_OBSERVED')
        boundary.assert_not_called()
        self.assertEqual(report['cloud_calls'], 0)
        self.assertFalse(report['published'])

    def test_help_never_opens_session(self):
        for module in (deploy_bronze, deploy_continuacao):
            with self.subTest(module=module.__name__), patch.object(module, 'checked_session') as boundary:
                with self.assertRaises(SystemExit) as exit_status:
                    self.invoke(module, ['--help'])
                self.assertEqual(exit_status.exception.code, 0)
                boundary.assert_not_called()

    def test_glue_tag_lookup_uses_selected_partition(self):
        for region, partition in [('us-east-2', 'aws'), ('cn-north-1', 'aws-cn'), ('us-gov-west-1', 'aws-us-gov')]:
            with self.subTest(region=region), tempfile.TemporaryDirectory() as tmp:
                session, glue, s3 = MagicMock(), MagicMock(), MagicMock()
                glue.exceptions.EntityNotFoundException = type('NotFound', (Exception,), {})
                glue.get_job.return_value = {'Job': {'Role': ROLE}}
                glue.get_tags.side_effect = RuntimeError('stop after ARN')
                session.client.side_effect = lambda service: {'glue': glue, 's3': s3}[service]
                arguments = COMMON[:-2] + ['--role-arn', f'arn:{partition}:iam::{ACCOUNT}:role/GlueExecution', '--region', region]
                with patch.object(deploy_continuacao, 'checked_session', return_value=session):
                    with self.assertRaisesRegex(RuntimeError, 'stop after ARN'):
                        self.invoke(deploy_continuacao, arguments + ['--layer', 'silver', '--source-manifest-uri', 's3://dados-fiap-exemplo/auditoria/bronze/run_id=x/manifest.json', '--update-existing', '--output', str(Path(tmp) / 'plan.json')])
                glue.get_tags.assert_called_once_with(ResourceArn=f'arn:{partition}:glue:{region}:{ACCOUNT}:job/fiap-silver-inep-batch')
                s3.put_object.assert_not_called()

    def test_region_role_partition_mismatch_is_local_error(self):
        with patch.object(deploy_bronze, 'checked_session') as boundary:
            with self.assertRaises(SystemExit):
                self.invoke(deploy_bronze, COMMON + ['--region', 'cn-north-1', '--connection-name', 'BigQuery', '--parent-project', 'projeto-exemplo-123'])
        boundary.assert_not_called()

    def test_wrong_source_layer_is_rejected_before_client(self):
        for layer, unexpected in [('silver', 'silver'), ('gold', 'bronze'), ('gold', 'gold')]:
            with self.subTest(layer=layer, source=unexpected), patch.object(deploy_continuacao, 'checked_session') as boundary:
                with self.assertRaises(SystemExit):
                    self.invoke(deploy_continuacao, COMMON + ['--layer', layer, '--source-manifest-uri', f's3://dados-fiap-exemplo/auditoria/{unexpected}/run_id=x/manifest.json', '--output', 'not-written.json'])
                boundary.assert_not_called()

    def test_manifest_without_valid_unique_run_id_is_local_error(self):
        paths = ['auditoria/bronze/manifest.json', 'auditoria/bronze/run_id=/manifest.json',
                 'auditoria/bronze/run_id=x/another/manifest.json',
                 'auditoria/bronze/run_id=x/run_id=y/manifest.json',
                 'auditoria/bronze/../run_id=x/manifest.json']
        for path in paths:
            with self.subTest(path=path), patch.object(deploy_continuacao, 'checked_session') as boundary:
                with self.assertRaises(SystemExit):
                    self.invoke(deploy_continuacao, COMMON + ['--layer', 'silver', '--source-manifest-uri', 's3://dados-fiap-exemplo/' + path, '--output', 'not-written.json'])
                boundary.assert_not_called()

    def test_dated_source_manifest_is_accepted_without_modification(self):
        for layer, date in [('bronze', 'ingestion_date=2026-10-20'), ('silver', 'process_date=2026-10-22')]:
            uri = f's3://dados-fiap-exemplo/auditoria/{layer}/{date}/run_id=jr_exemplo-123/manifest.json'
            self.assertEqual(configuration.validate_manifest(uri, 'dados-fiap-exemplo', layer), uri)

    def test_observer_rejects_invalid_s3_bucket_before_inspection(self):
        for bucket in ['127.0.0.1', 'dados..fiap', 'dados.-fiap']:
            with self.subTest(bucket=bucket), patch.object(verify_continuacao, 'inspect') as boundary:
                with self.assertRaises(SystemExit):
                    self.invoke(verify_continuacao, ['--account-id', ACCOUNT, '--bucket', bucket, '--layer', 'gold', '--run-id', 'jr_exemplo', '--output', 'not-written.json'])
                boundary.assert_not_called()

    def test_observer_rejects_invalid_job_name_before_inspection(self):
        with patch.object(verify_continuacao, 'inspect') as boundary:
            with self.assertRaises(SystemExit):
                self.invoke(verify_continuacao, ['--account-id', ACCOUNT, '--bucket', 'dados-fiap-exemplo', '--layer', 'gold', '--run-id', 'jr_exemplo', '--job-name', 'job;invalid', '--output', 'not-written.json'])
        boundary.assert_not_called()


if __name__ == '__main__':
    unittest.main()
