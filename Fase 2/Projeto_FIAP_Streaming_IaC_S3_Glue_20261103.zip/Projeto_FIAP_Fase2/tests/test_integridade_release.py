"""Integridade offline: alteracoes reais, manifesto circular e paths maliciosos."""
from contextlib import redirect_stdout, redirect_stderr
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("release_integrity", ROOT / "tools/manifesto_release.py")
release = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(release)
VERIFY_SPEC = importlib.util.spec_from_file_location("verify_release_integrity", ROOT / "tools/verificar_integridade.py")
verifier = importlib.util.module_from_spec(VERIFY_SPEC)
VERIFY_SPEC.loader.exec_module(verifier)


class ReleaseIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        (self.root / "dados").mkdir()
        (self.root / "dados/original.bin").write_bytes(b"preservar\x00\xff\n")
        (self.root / "README.txt").write_text("versao A", encoding="utf-8")

    def manifest(self):
        return release.write(self.root, version="test")

    def update_document(self, mutate):
        path = self.root / release.DEFAULT_MANIFEST
        document = json.loads(path.read_text(encoding="utf-8"))
        mutate(document)
        path.write_text(json.dumps(document), encoding="utf-8")

    def test_unchanged_release_passes_and_manifest_excludes_itself(self):
        path = self.manifest()
        document = json.loads(path.read_text(encoding="utf-8"))
        self.assertNotIn(path.name, document["files"])
        self.assertTrue(release.verify(self.root)["ok"])
        self.assertEqual(release.verify(self.root)["matched"], 2)

    def test_same_length_tampering_is_detected(self):
        self.manifest()
        (self.root / "README.txt").write_text("versao B", encoding="utf-8")
        result = release.verify(self.root)
        self.assertFalse(result["ok"])
        self.assertEqual(result["changed"], ["README.txt"])

    def test_missing_data_is_detected(self):
        self.manifest()
        (self.root / "dados/original.bin").unlink()
        self.assertEqual(release.verify(self.root)["missing"], ["dados/original.bin"])

    def test_new_file_is_detected_even_when_gitignored(self):
        (self.root / ".gitignore").write_text("*.env\n", encoding="utf-8")
        self.manifest()
        (self.root / "unexpected.env").write_text("not-a-secret", encoding="utf-8")
        self.assertEqual(release.verify(self.root)["new"], ["unexpected.env"])

    def test_only_root_git_metadata_is_exempt(self):
        self.manifest()
        (self.root / ".git").mkdir()
        (self.root / ".git/config").write_text("local metadata", encoding="utf-8")
        self.assertTrue(release.verify(self.root)["ok"])
        (self.root / "dados/.git").mkdir()
        (self.root / "dados/.git/file").write_text("not root metadata", encoding="utf-8")
        self.assertEqual(release.verify(self.root)["new"], ["dados/.git/file"])

    def test_empty_manifest_cannot_certify_release(self):
        self.manifest()
        self.update_document(lambda doc: doc.update(files={}))
        with self.assertRaisesRegex(ValueError, "vazio"):
            release.verify(self.root)

    def test_path_escape_and_absolute_paths_rejected(self):
        info = {"bytes": 0, "sha256": "0" * 64}
        for path in ("../outside", "/absolute", "C:/drive", "a/../b", "a//b", "a\\b"):
            with self.subTest(path=path), self.assertRaises(ValueError):
                release.validate_entries({path: info})
        with self.assertRaises(ValueError):
            release.manifest_location(self.root, "../outside.json")

    def test_self_inclusion_and_case_ambiguity_rejected(self):
        info = {"bytes": 0, "sha256": "0" * 64}
        with self.assertRaisesRegex(ValueError, "circular"):
            release.validate_entries({release.DEFAULT_MANIFEST: info}, release.DEFAULT_MANIFEST)
        with self.assertRaisesRegex(ValueError, "duplicados"):
            release.validate_entries({"A.txt": info, "a.txt": info})

    def test_extra_exclusions_cannot_hide_files(self):
        self.manifest()
        self.update_document(lambda doc: doc.update(ignored_root_metadata=[".git", "dados"]))
        with self.assertRaisesRegex(ValueError, "Exclusoes"):
            release.verify(self.root)

    def test_invalid_hash_size_and_duplicate_json_keys_rejected(self):
        for info in ({"bytes": -1, "sha256": "0" * 64}, {"bytes": True, "sha256": "0" * 64}, {"bytes": 1, "sha256": "wrong"}):
            with self.subTest(info=info), self.assertRaises(ValueError):
                release.validate_entries({"a.txt": info})
        path = self.root / "duplicate.json"
        path.write_text('{"a": 1, "a": 2}', encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "repetida"):
            release.read_json(path)

    def test_replace_requires_explicit_flag_and_historical_manifest_protected(self):
        self.manifest()
        with self.assertRaisesRegex(ValueError, "ja existe"):
            release.write(self.root)
        with self.assertRaisesRegex(ValueError, "historico"):
            release.write(self.root, "SHA256_Arquivos.json")
        with self.assertRaisesRegex(ValueError, "historico"):
            release.write(self.root, "sha256_arquivos.json", replace=True)

    def test_manifest_outside_root_rejected(self):
        with self.assertRaisesRegex(ValueError, "dentro da raiz"):
            release.manifest_location(self.root, self.root.parent / "outside.json")

    def test_symlink_file_rejected_when_platform_permits_creation(self):
        link = self.root / "link.txt"
        try:
            link.symlink_to(self.root / "README.txt")
        except (OSError, NotImplementedError):
            self.skipTest("Sistema nao permite symlink sem privilegio adicional")
        with self.assertRaisesRegex(ValueError, "regular"):
            release.build(self.root)

    def test_symlink_metadata_rejected_even_without_os_privilege(self):
        link = self.root / "link.txt"
        link.write_text("fixture de metadado symlink", encoding="utf-8")
        with patch.object(Path, "is_symlink", new=lambda path: path == link):
            with self.assertRaisesRegex(ValueError, "regular"):
                release.build(self.root)

    def test_public_verifier_rejects_new_files_and_missing_manifest(self):
        self.manifest()
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            self.assertEqual(verifier.main(["--raiz", str(self.root)]), 0)
            (self.root / "new.txt").write_text("nao previsto", encoding="utf-8")
            self.assertEqual(verifier.main(["--raiz", str(self.root)]), 1)
            (self.root / release.DEFAULT_MANIFEST).unlink()
            self.assertEqual(verifier.main(["--raiz", str(self.root)]), 2)

    def test_historical_hash_difference_is_never_reported_as_success(self):
        historical = release.inventory(self.root, "SHA256_Arquivos.json")
        historical["historico_omitido.txt"] = {"bytes": 0, "sha256": "0" * 64}
        (self.root / "SHA256_Arquivos.json").write_text(json.dumps(historical), encoding="utf-8")
        (self.root / ".gitignore").write_text("/historico_omitido.txt\n", encoding="utf-8")
        (self.root / "README.txt").write_text("versao B", encoding="utf-8")
        result = verifier.historical_comparison(self.root)
        self.assertEqual(result["excluded"], ["historico_omitido.txt"])
        self.assertEqual(result["changed"], ["README.txt"])
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            self.assertEqual(verifier.main(["--raiz", str(self.root), "--historico"]), 1)

    def test_cli_exit_codes_for_tampered_and_malformed_manifest(self):
        self.manifest()
        (self.root / "README.txt").write_text("alterado", encoding="utf-8")
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            self.assertEqual(release.main(["--raiz", str(self.root)]), 1)
            (self.root / release.DEFAULT_MANIFEST).write_text("{}", encoding="utf-8")
            self.assertEqual(release.main(["--raiz", str(self.root)]), 2)


if __name__ == "__main__":
    unittest.main()
