"""Offline contracts for NEW-environment S3/Glue IaC; no SDK or real network."""
import ast
import builtins
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import socket
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / 'infra/batch/gerar_iac.py'
spec = importlib.util.spec_from_file_location('batch_storage_generator', PATH)
iac = importlib.util.module_from_spec(spec)
spec.loader.exec_module(iac)


def config():
    return json.loads((ROOT / 'infra/batch/ambiente.example.json').read_text(encoding='utf-8'))


def params_dict(values):
    return {entry['ParameterKey']: entry['ParameterValue'] for entry in values}


def resolve(value, template, parameters):
    refs = {key: definition['Default'] for key, definition in template['Parameters'].items()
            if 'Default' in definition}
    refs.update(parameters)
    refs.update({'AWS::Partition': 'aws', 'AWS::AccountId': '111122223333',
                 'AWS::Region': 'eu-west-1'})
    for layer in iac.LAYERS:
        refs[layer.title() + 'Job'] = parameters[layer.title() + 'JobName']
    refs.update(SilverDatabase=parameters['SilverDatabaseName'], GoldDatabase=parameters['GoldDatabaseName'])
    def visit(item):
        if isinstance(item, list):
            return [visit(x) for x in item]
        if not isinstance(item, dict):
            return item
        if set(item) == {'Ref'}:
            return refs[item['Ref']]
        if set(item) == {'Fn::Sub'}:
            return re.sub(r'\$\{([^}]+)\}', lambda m: str(refs[m.group(1)]), item['Fn::Sub'])
        if set(item) == {'Fn::Equals'}:
            a, b = visit(item['Fn::Equals'])
            return a == b
        if set(item) == {'Fn::Not'}:
            return not visit(item['Fn::Not'][0])
        if set(item) == {'Fn::If'}:
            condition, yes, no = item['Fn::If']
            return visit(yes if visit(template['Conditions'][condition]) else no)
        return {key: visit(val) for key, val in item.items()}
    return visit(value)


class BatchStorageInfrastructure(unittest.TestCase):
    def assets(self, cfg=None):
        cfg = cfg or config()
        return iac.asset_manifest(cfg['assets_bucket'], cfg['jobs'])

    def prepared(self, cfg=None):
        cfg = cfg or config()
        return iac.prepare_parameters(cfg, self.assets(cfg))

    def test_saved_templates_are_deterministic_generated_templates(self):
        for name, build in [('storage_stack.json', iac.build_storage), ('batch_stack.json', iac.build_batch)]:
            saved = (ROOT / 'infra/batch' / name).read_text(encoding='utf-8')
            self.assertEqual(saved, iac.encode(build()))

    def test_storage_is_separate_retained_private_encrypted_and_has_no_expiry(self):
        template = iac.build_storage()
        self.assertEqual({k: v['Type'] for k, v in template['Resources'].items()},
                         {'DataBucket': 'AWS::S3::Bucket', 'AssetsBucket': 'AWS::S3::Bucket'})
        self.assertTrue(template['Rules']['DifferentBuckets']['Assertions'])
        for resource in template['Resources'].values():
            self.assertEqual(resource['DeletionPolicy'], 'Retain')
            self.assertEqual(resource['UpdateReplacePolicy'], 'Retain')
            props = resource['Properties']
            self.assertIsInstance(props['BucketName'], dict)
            self.assertTrue(all(props['PublicAccessBlockConfiguration'].values()))
            self.assertEqual(props['OwnershipControls']['Rules'], [{'ObjectOwnership': 'BucketOwnerEnforced'}])
            self.assertEqual(props['BucketEncryption']['ServerSideEncryptionConfiguration'][0]
                             ['ServerSideEncryptionByDefault']['SSEAlgorithm'], 'AES256')
            self.assertNotIn('LifecycleConfiguration', props)
            self.assertNotIn('VersioningConfiguration', props)
            self.assertNotIn('AccessControl', props)

    def test_only_three_jobs_and_two_databases_no_triggers_or_iam(self):
        template = iac.build_batch()
        types = [resource['Type'] for resource in template['Resources'].values()]
        self.assertEqual(sorted(types), ['AWS::Glue::Database'] * 2 + ['AWS::Glue::Job'] * 3)
        for resource in template['Resources'].values():
            self.assertEqual(resource['DeletionPolicy'], 'Retain')
            self.assertEqual(resource['UpdateReplacePolicy'], 'Retain')
        for name in ('SilverDatabase', 'GoldDatabase'):
            props = template['Resources'][name]['Properties']
            self.assertEqual(props['CatalogId'], {'Ref': 'AWS::AccountId'})
            self.assertEqual(props['DatabaseInput']['Name'], {'Ref': name + 'Name'})
        self.assertNotIn('ScheduleExpression', iac.encode(template))

    def test_cfn_job_shape_has_list_tags_and_preserves_compute_caps(self):
        template = iac.build_batch()
        for layer in iac.LAYERS:
            props = template['Resources'][layer.title() + 'Job']['Properties']
            self.assertEqual(props['Command']['Name'], 'glueetl')
            self.assertEqual(props['Command']['PythonVersion'], '3')
            self.assertEqual(props['GlueVersion'], '5.1')
            self.assertEqual((props['WorkerType'], props['NumberOfWorkers']), ('G.1X', 2))
            self.assertEqual(props['ExecutionProperty'], {'MaxConcurrentRuns': 1})
            self.assertEqual(props['MaxRetries'], 0)
            self.assertEqual(props['Timeout'], 30 if layer == 'bronze' else 15)
            self.assertEqual(props['ExecutionClass'], 'STANDARD')
            self.assertIsInstance(props['Tags'], list)
            self.assertEqual(set(props['Tags'][0]), {'Key', 'Value'})
            self.assertNotIn('MaxCapacity', props)

    def test_all_template_refs_and_substitutions_are_declared(self):
        for template in (iac.build_storage(), iac.build_batch()):
            known = set(template['Parameters']) | set(template['Resources']) | {
                'AWS::AccountId', 'AWS::Region', 'AWS::Partition'}
            def walk(item):
                if isinstance(item, list):
                    for child in item:
                        walk(child)
                elif isinstance(item, dict):
                    if set(item) == {'Ref'}:
                        self.assertIn(item['Ref'], known)
                    if set(item) == {'Fn::Sub'}:
                        for variable in re.findall(r'\$\{([^}]+)\}', item['Fn::Sub']):
                            self.assertIn(variable, known)
                    if set(item) == {'Fn::If'}:
                        self.assertIn(item['Fn::If'][0], template['Conditions'])
                    for child in item.values():
                        walk(child)
            walk(template)

    def test_bootstrap_explicit_empty_manifest_does_not_use_historical_defaults(self):
        template = iac.build_batch()
        parameters = params_dict(self.prepared()['batch_parameters.json'])
        for layer, source in [('Silver', 'BRONZE'), ('Gold', 'SILVER')]:
            props = resolve(template['Resources'][layer + 'Job']['Properties'], template, parameters)
            self.assertIn('--' + source + '_MANIFEST_URI', props['DefaultArguments'])
            self.assertEqual(props['DefaultArguments']['--' + source + '_MANIFEST_URI'], '')
        plan = self.prepared()['local_plan.json']
        self.assertEqual(set(plan['manifest_states'].values()), {'EMPTY_BOOTSTRAP_FAIL_CLOSED'})

    def test_existing_silver_and_gold_guards_reject_empty_before_cloud_or_spark(self):
        # Execute the actual stdlib Silver parser, not a rewritten approximation.
        name = 'batch_storage_silver_parser'
        silver_spec = importlib.util.spec_from_file_location(name, ROOT / 'silver/silver_glue.py')
        silver = importlib.util.module_from_spec(silver_spec)
        with patch.dict(sys.modules, {name: silver}):
            silver_spec.loader.exec_module(silver)
            with self.assertRaisesRegex(ValueError, 'URI S3'):
                silver.parse_config(['--JOB_NAME', 'exemplo-silver', '--BUCKET', 'dados-exemplo-local',
                                     '--BRONZE_MANIFEST_URI', ''])
        # Gold imports SDK/Spark globally. Extract its existing guard function via
        # AST only, then prove the guard rejects before its SDK call is reached.
        source = ast.parse((ROOT / 'gold/gold_glue.py').read_text(encoding='utf-8'))
        node = next(item for item in source.body if isinstance(item, ast.FunctionDef) and item.name == 'inspect_silver')
        sdk = Mock()
        sdk.client.side_effect = AssertionError('No SDK call is allowed')
        namespace = {'urlparse': urlparse, 'boto3': sdk}
        exec(compile(ast.Module(body=[node], type_ignores=[]), 'gold_guard_only', 'exec'), namespace)
        with self.assertRaisesRegex(RuntimeError, 'BLOCKED_MISSING_SILVER'):
            namespace['inspect_silver'](None, {'SILVER_MANIFEST_URI': ''})
        sdk.client.assert_not_called()

    def test_nonempty_manifests_keep_explicit_layer_run_and_bucket(self):
        cfg = config()
        cfg['bronze_manifest_uri'] = 's3://' + cfg['data_bucket'] + '/auditoria/bronze/ingestion_date=2030-01-02/run_id=escolhido_b/manifest.json'
        cfg['silver_manifest_uri'] = 's3://' + cfg['data_bucket'] + '/auditoria/silver/process_date=2030-01-03/run_id=escolhido_s/manifest.json'
        result = self.prepared(cfg)
        template = iac.build_batch()
        parameters = params_dict(result['batch_parameters.json'])
        for layer, source in [('Silver', 'bronze'), ('Gold', 'silver')]:
            args = resolve(template['Resources'][layer + 'Job']['Properties']['DefaultArguments'], template, parameters)
            self.assertEqual(args['--' + source.upper() + '_MANIFEST_URI'], cfg[source + '_manifest_uri'])
        self.assertEqual(set(result['local_plan.json']['manifest_states'].values()),
                         {'URI_VALIDATED_ONLY_SUCCESS_AND_CONTENT_NOT_CHECKED'})

    def test_manifest_refuses_cross_bucket_layer_query_traversal_or_duplicate_run(self):
        bad = ['s3://outro-bucket/auditoria/bronze/run_id=um/manifest.json',
               's3://bucket-local/auditoria/silver/run_id=um/manifest.json',
               's3://bucket-local/auditoria/bronze/run_id=um/manifest.json?x=1',
               's3://bucket-local/auditoria/bronze/../run_id=um/manifest.json',
               's3://bucket-local/auditoria/bronze/run_id=um/run_id=dois/manifest.json',
               's3://bucket-local/auditoria/bronze/run_id=um/not-manifest.json',
               's3://bucket-local/auditoria/bronze/run_id=/manifest.json']
        for uri in bad:
            with self.subTest(uri=uri), self.assertRaises(ValueError):
                iac.manifest_key(uri, 'bucket-local', 'bronze')

    def test_arguments_match_current_defaults_without_copying_old_environment(self):
        template = iac.build_batch()
        cfg = config()
        parameters = params_dict(self.prepared(cfg)['batch_parameters.json'])
        for layer in iac.LAYERS:
            props = resolve(template['Resources'][layer.title() + 'Job']['Properties'], template, parameters)
            args = props['DefaultArguments']
            self.assertEqual(args['--job-bookmark-option'], 'job-bookmark-disable')
            self.assertEqual(args['--BUCKET' if layer != 'gold' else '--S3_BUCKET'], cfg['data_bucket'])
            self.assertEqual(props['Role'], cfg['roles'][layer])
            self.assertEqual(props['Command']['ScriptLocation'], self.assets(cfg)['scripts'][layer]['uri'])
            if layer == 'bronze':
                self.assertEqual(props['Connections'], {'Connections': [cfg['connection_name']]})
                self.assertEqual(args['--TABLES'], iac.TABLES)
                self.assertEqual(args['--PARENT_PROJECT'], cfg['parent_project'])
            else:
                defaults = json.loads((ROOT / layer / 'job_defaults.json').read_text(encoding='utf-8-sig'))
                environment = {'--BUCKET', '--S3_BUCKET', '--BRONZE_MANIFEST_URI', '--SILVER_MANIFEST_URI',
                               '--DATABASE_SILVER', '--DATABASE_GOLD'}
                for key, value in defaults.items():
                    if key not in environment:
                        self.assertEqual(args[key], value, (layer, key))

    def test_asset_manifest_hashes_and_content_addressed_uris_match_all_scripts(self):
        assets = self.assets()
        self.assertEqual(assets['status'], 'PENDING_UPLOAD')
        self.assertFalse(assets['cloud_verified'])
        for layer, record in assets['scripts'].items():
            data = (ROOT / layer / (layer + '_glue.py')).read_bytes()
            self.assertEqual(record['sha256'], hashlib.sha256(data).hexdigest())
            self.assertEqual(record['bytes'], len(data))
            self.assertIn('/' + record['sha256'] + '/', record['uri'])
            self.assertEqual(record['local_file'], layer + '/' + layer + '_glue.py')

    def test_asset_manifest_mismatches_are_fail_closed(self):
        for field, replacement in [('sha256', '0' * 64), ('bytes', 1),
                                   ('uri', 's3://outro-bucket/arquivo.py'), ('local_file', '../../arquivo.py')]:
            bad = self.assets()
            bad['scripts']['gold'][field] = replacement
            with self.subTest(field=field), self.assertRaises(ValueError):
                iac.prepare_parameters(config(), bad)
        for change in ('cloud_verified', 'status', 'missing', 'extra'):
            bad = self.assets()
            if change == 'cloud_verified': bad['cloud_verified'] = True
            elif change == 'status': bad['status'] = 'UPLOADED'
            elif change == 'missing': del bad['scripts']['bronze']
            else: bad['scripts']['extra'] = {}
            with self.subTest(change=change), self.assertRaises(ValueError):
                iac.prepare_parameters(config(), bad)

    def test_configuration_refuses_foreign_account_partition_duplicate_names_and_buckets(self):
        invalid = []
        for field, value in [('account_id', '123'), ('region', 'not-region'),
                             ('data_bucket', '192.168.1.2'), ('gold_database', 'NomeInvalido'),
                             ('connection_name', '   '), ('parent_project', 'bad')]:
            bad = config(); bad[field] = value; invalid.append(bad)
        bad = config(); bad['roles']['bronze'] = 'arn:aws:iam::999900001111:role/Foreign'; invalid.append(bad)
        bad = config(); bad['region'] = 'cn-north-1'; invalid.append(bad)
        bad = config(); bad['jobs']['silver'] = bad['jobs']['bronze']; invalid.append(bad)
        bad = config(); bad['data_bucket'] = bad['assets_bucket']; invalid.append(bad)
        bad = config(); bad['gold_database'] = bad['silver_database']; invalid.append(bad)
        for bad in invalid:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                iac.prepare_parameters(bad, self.assets())

    def test_arbitrary_configuration_changes_produce_other_account_safe_templates(self):
        cfg = config()
        cfg.update(account_id='444455556666', region='us-gov-west-1', data_bucket='autro-dados-exemplo',
                   assets_bucket='outro-assets-exemplo', silver_database='outra_silver', gold_database='outra_gold')
        cfg['jobs'] = {layer: 'outro-' + layer for layer in iac.LAYERS}
        cfg['roles'] = {layer: 'arn:aws-us-gov:iam::444455556666:role/Outro' for layer in iac.LAYERS}
        result = self.prepared(cfg)
        params = params_dict(result['batch_parameters.json'])
        self.assertEqual(params['GoldRoleArn'], cfg['roles']['gold'])
        self.assertEqual(params['GoldJobName'], 'outro-gold')
        self.assertEqual(result['local_plan.json']['expected_region'], 'us-gov-west-1')
        # Local portability only; this does not assert Glue/BigQuery availability.
        self.assertFalse(result['local_plan.json']['identity_or_region_verified_in_cloud'])

    def test_cli_every_path_runs_with_no_sdk_import_or_network(self):
        imported = builtins.__import__
        def guarded(name, *args, **kwargs):
            if name.split('.')[0] in {'boto3', 'botocore', 'pyspark', 'requests', 'httpx', 'subprocess'}:
                raise AssertionError('External operation/import forbidden: ' + name)
            return imported(name, *args, **kwargs)
        cfg = config()
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            with patch('builtins.__import__', side_effect=guarded), \
                 patch.object(socket.socket, 'connect', side_effect=AssertionError('No network')), \
                 contextlib.redirect_stdout(io.StringIO()):
                iac.main(['templates', '--output-dir', str(base / 'templates')])
                iac.main(['assets', '--assets-bucket', cfg['assets_bucket'], '--bronze-job', cfg['jobs']['bronze'],
                          '--silver-job', cfg['jobs']['silver'], '--gold-job', cfg['jobs']['gold'],
                          '--output', str(base / 'assets.json')])
                iac.main(['parameters', '--config', str(ROOT / 'infra/batch/ambiente.example.json'),
                          '--asset-manifest', str(base / 'assets.json'), '--output-dir', str(base / 'params')])
            self.assertTrue((base / 'params/batch_parameters.json').is_file())

    def test_existing_files_and_directories_are_not_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            original = base / 'original.json'
            original.write_bytes(b'PRESERVE EXACT BYTES')
            with self.assertRaises(FileExistsError):
                iac.write_new(original, {'overwrite': True})
            self.assertEqual(original.read_bytes(), b'PRESERVE EXACT BYTES')
            out = base / 'existing'
            out.mkdir()
            marker = out / 'storage_stack.json'
            marker.write_bytes(b'OLD TEMPLATE')
            with self.assertRaises(FileExistsError):
                iac.write_directory(out, {'storage_stack.json': iac.build_storage(), 'batch_stack.json': iac.build_batch()})
            self.assertEqual(marker.read_bytes(), b'OLD TEMPLATE')
            self.assertFalse((out / 'batch_stack.json').exists())

    def test_unknown_duplicate_and_nonfinite_json_inputs_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory) / 'bad.json'
            for text in ('{"key":1,"key":2}', '{"key":NaN}'):
                file.write_text(text, encoding='utf-8')
                with self.assertRaises(ValueError):
                    iac.read_json(file)
        cfg = config(); cfg['unknown_setting'] = 'not silently ignored'
        with self.assertRaises(ValueError):
            iac.prepare_parameters(cfg, self.assets())

    def test_no_deployed_claim_or_historical_environment_ids_in_templates_and_example(self):
        text = iac.encode(iac.build_storage()) + iac.encode(iac.build_batch()) + iac.encode(config())
        for value in ('637246457028', 'fiap-tc-fase2-2026', 'fiap1-512214', 'jr_cdfd2933', 'jr_9c58c50a'):
            self.assertNotIn(value, text)
        for template in (iac.build_storage(), iac.build_batch()):
            self.assertEqual(template['Metadata']['Status'], 'OFFLINE_NEW_ENVIRONMENT_PROPOSAL_NOT_DEPLOYED')
        self.assertFalse(self.prepared()['local_plan.json']['import_ready'])


if __name__ == '__main__':
    unittest.main()
