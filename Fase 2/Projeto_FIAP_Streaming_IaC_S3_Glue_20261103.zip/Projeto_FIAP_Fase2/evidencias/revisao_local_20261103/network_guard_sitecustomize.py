import os, socket
def blocked(*args, **kwargs):
    with open(os.environ['FIAP_OFFLINE_NETWORK_LOG'], 'a', encoding='utf-8') as f:
        f.write('Blocked network connection attempt\n')
    raise RuntimeError('Network is disabled for the local FIAP test suite')
socket.socket.connect = blocked
socket.socket.connect_ex = blocked
socket.create_connection = blocked
