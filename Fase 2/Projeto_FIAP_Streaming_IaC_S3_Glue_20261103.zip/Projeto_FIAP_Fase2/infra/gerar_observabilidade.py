"""Generate a reusable, UNDEPLOYED template locally, without credentials/network.

Historical import evidence remains untouched. This is a CREATE reference for a
separate environment, not an import/update plan for the existing AWS resources.
Email is disabled by default and must be explicitly supplied at deployment.
"""
import argparse
import copy
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def name(value, label, limit=64):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,' + str(limit) + '}', value):
        raise ValueError('Invalid ' + label)
    return value


def sub(text):
    return {'Fn::Sub': text}


def build(*, topic_name='fiap-inep-alertas-operacionais', bronze_job='fiap-bronze-inep-batch',
          silver_job='fiap-silver-inep-batch', gold_job='fiap-gold-inep-batch',
          rule_name='fiap-inep-batch-failures', pipeline='fiap-inep-streaming'):
    for label, value in [('topic', topic_name), ('bronze job', bronze_job), ('silver job', silver_job),
                         ('gold job', gold_job), ('rule', rule_name), ('pipeline', pipeline)]:
        name(value, label)
    alarm_names = [silver_job.replace('-batch', '') + '-failure', gold_job.replace('-batch', '') + '-failure',
                   pipeline + '-dlq', pipeline + '-rejected', pipeline + '-age']
    if len({bronze_job, silver_job, gold_job}) != 3 or len(set(alarm_names)) != len(alarm_names):
        raise ValueError('Jobs and physical alarm names must be distinct')
    reference = ROOT / 'observabilidade/cloudformation/aplicado_20261028/import_template.json'
    template = copy.deepcopy(json.loads(reference.read_text(encoding='utf-8')))
    template['Description'] = 'REFERENCIA REUTILIZAVEL NAO IMPLANTADA: falhas batch e SNS opcional; sem agendamento.'
    template['Metadata'] = {'Purpose': 'LOCAL_GENERATION_ONLY', 'HistoricalEvidence': reference.relative_to(ROOT).as_posix(),
                            'ExistingEnvironment': 'Do not use as an import or update plan'}
    template['Parameters'] = {
        'TopicName': {'Type': 'String', 'Default': topic_name},
        'BronzeJobName': {'Type': 'String', 'Default': bronze_job},
        'SilverJobName': {'Type': 'String', 'Default': silver_job},
        'GoldJobName': {'Type': 'String', 'Default': gold_job},
        'AlertEmail': {'Type': 'String', 'Default': '',
                       'Description': 'Empty disables email. A supplied address receives an SNS confirmation after deployment.',
                       'AllowedPattern': r'^$|^[^\s@]+@[^\s@]+\.[^\s@]+$'},
    }
    template['Conditions'] = {'EnableEmail': {'Fn::Not': [{'Fn::Equals': [{'Ref': 'AlertEmail'}, '']}]}}
    resources = template['Resources']
    resources['AlertTopic']['Properties']['TopicName'] = {'Ref': 'TopicName'}
    subscription = resources['AlertSubscription']
    subscription['Condition'] = 'EnableEmail'
    subscription['Properties']['Endpoint'] = {'Ref': 'AlertEmail'}
    statements = resources['AlertTopicPolicy']['Properties']['PolicyDocument']['Statement']
    for statement in statements:
        conditions = statement.get('Condition', {}).get('StringEquals', {})
        for key in ('AWS:SourceOwner', 'aws:SourceAccount'):
            if key in conditions:
                conditions[key] = {'Ref': 'AWS::AccountId'}
        if statement.get('Sid') == 'OnlyProjectCloudWatchAlarms':
            statement['Condition']['ArnEquals']['aws:SourceArn'] = [
                sub('arn:${AWS::Partition}:cloudwatch:${AWS::Region}:${AWS::AccountId}:alarm:' + alarm)
                for alarm in alarm_names]
        if statement.get('Sid') == 'OnlyEventBridgeFromThisAccount':
            statement['Condition']['ArnEquals'] = {'aws:SourceArn': sub('arn:${AWS::Partition}:events:${AWS::Region}:${AWS::AccountId}:rule/' + rule_name)}
    rule = resources['BatchFailureRule']['Properties']
    rule['Name'] = rule_name
    rule['EventPattern']['detail']['jobName'] = [{'Ref': 'BronzeJobName'}, {'Ref': 'SilverJobName'}, {'Ref': 'GoldJobName'}]
    for logical, param, job in [('SilverFailureAlarm', 'SilverJobName', silver_job), ('GoldFailureAlarm', 'GoldJobName', gold_job)]:
        props = resources[logical]['Properties']
        props['AlarmName'] = job.replace('-batch', '') + '-failure'
        props['AlarmDescription'] = 'Falha batch; verificar logs e manifesto de qualidade. SNS vinculado; email opcional.'
        for dimension in props['Dimensions']:
            if dimension['Name'] == 'JobName':
                dimension['Value'] = {'Ref': param}
    template['Outputs'] = {'AlertTopicArn': {'Value': {'Ref': 'AlertTopic'}}}
    return template


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='New local JSON file')
    for flag, default in [('topic-name', 'fiap-inep-alertas-operacionais'), ('bronze-job', 'fiap-bronze-inep-batch'),
                          ('silver-job', 'fiap-silver-inep-batch'), ('gold-job', 'fiap-gold-inep-batch'),
                          ('rule-name', 'fiap-inep-batch-failures'), ('pipeline', 'fiap-inep-streaming')]:
        parser.add_argument('--' + flag, default=default)
    args = parser.parse_args(argv)
    template = build(**{key: value for key, value in vars(args).items() if key != 'output'})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as output:
        output.write(json.dumps(template, ensure_ascii=False, indent=2) + '\n')
    print('LOCAL_ONLY: template generated; no deployment, subscription or AWS calls: ' + str(args.output))


if __name__ == '__main__':
    main()
