"""Generate NEW-environment CloudFormation artifacts on disk, using stdlib only.

This module has no cloud client, deployment operation or network access. Existing
resources require a separate snapshot-based import review; see LEIA-ME.txt.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urlsplit


ROOT = Path(__file__).resolve().parents[2]
LAYERS = ('bronze', 'silver', 'gold')
TABLES = ('alunos,municipio,uf,meta_alfabetizacao_brasil,meta_alfabetizacao_uf,'
          'meta_alfabetizacao_municipio,dicionario')
BUCKET_PATTERN = r'[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]'
NAME_PATTERN = r'[a-zA-Z0-9_-]{1,200}'
DATABASE_PATTERN = r'[a-z][a-z0-9_]{0,127}'
ROLE_PATTERN = r'arn:(aws|aws-us-gov|aws-cn):iam::([0-9]{12}):role/([A-Za-z0-9_+=,.@/-]+)'


def ref(name):
    return {'Ref': name}


def sub(value):
    return {'Fn::Sub': value}


def parameter(description, pattern=None, default=None):
    result = {'Type': 'String', 'Description': description}
    if pattern:
        result['AllowedPattern'] = '^' + pattern + '$'
    if default is not None:
        result['Default'] = default
    return result


def retained(kind, properties, **extra):
    return dict(Type=kind, DeletionPolicy='Retain', UpdateReplacePolicy='Retain',
                Properties=properties, **extra)


def common_metadata():
    return {
        'Status': 'OFFLINE_NEW_ENVIRONMENT_PROPOSAL_NOT_DEPLOYED',
        'ExistingResources': 'Do not deploy directly over existing resources; review a separate IMPORT plan.',
        'NoExecution': 'No schedules, triggers, job starts, IAM grants or credentials are created.',
    }


def build_storage():
    parameters = {
        'DataBucketName': parameter('NEW data bucket name; must be globally available.', BUCKET_PATTERN),
        'AssetsBucketName': parameter('NEW scripts bucket name; different from data bucket.', BUCKET_PATTERN),
        'ProjectTag': parameter('Project tag; not an account identifier.', r'[A-Za-z0-9 _./=+-]{1,128}', 'FIAP-TC-Fase2'),
    }
    resources = {}
    for logical, name, component in (('DataBucket', 'DataBucketName', 'data'),
                                      ('AssetsBucket', 'AssetsBucketName', 'assets')):
        resources[logical] = retained('AWS::S3::Bucket', {
            'BucketName': ref(name),
            'BucketEncryption': {'ServerSideEncryptionConfiguration': [
                {'ServerSideEncryptionByDefault': {'SSEAlgorithm': 'AES256'}}]},
            'PublicAccessBlockConfiguration': {
                'BlockPublicAcls': True, 'BlockPublicPolicy': True,
                'IgnorePublicAcls': True, 'RestrictPublicBuckets': True},
            'OwnershipControls': {'Rules': [{'ObjectOwnership': 'BucketOwnerEnforced'}]},
            'Tags': [{'Key': 'Project', 'Value': ref('ProjectTag')},
                     {'Key': 'Component', 'Value': component}],
        })
    return {
        'AWSTemplateFormatVersion': '2010-09-09',
        'Description': 'OFFLINE PROPOSAL: two NEW retained S3 buckets; no data upload or deletion policy by age.',
        'Metadata': common_metadata(), 'Parameters': parameters,
        'Rules': {'DifferentBuckets': {'Assertions': [{
            'Assert': {'Fn::Not': [{'Fn::Equals': [ref('DataBucketName'), ref('AssetsBucketName')]}]},
            'AssertDescription': 'The two new bucket resources must have different names.'}]}},
        'Resources': resources,
        'Outputs': {
            'DataBucketName': {'Value': ref('DataBucket')},
            'AssetsBucketName': {'Value': ref('AssetsBucket')},
            'DataBucketArn': {'Value': {'Fn::GetAtt': ['DataBucket', 'Arn']}},
            'AssetsBucketArn': {'Value': {'Fn::GetAtt': ['AssetsBucket', 'Arn']}},
            'Region': {'Value': ref('AWS::Region')},
        },
    }


def build_batch():
    parameters = {
        'DataBucketName': parameter('Previously provisioned data bucket.', BUCKET_PATTERN),
        'AssetsBucketName': parameter('Previously provisioned bucket with uploaded, hash-verified scripts.', BUCKET_PATTERN),
        'ConnectionName': parameter('Existing Glue BigQuery connection; credentials remain outside this template.', r'[A-Za-z0-9_ .()/-]{1,200}'),
        'ParentProject': parameter('Existing GCP consumer project; no billing activation.', r'[a-z][a-z0-9-]{4,61}[a-z0-9]'),
        'SourceDataset': parameter('Public source project.dataset.', r'[a-z][a-z0-9-]{4,61}[a-z0-9]\.[A-Za-z_][A-Za-z0-9_]*',
                                   'basedosdados.br_inep_avaliacao_alfabetizacao'),
        'SilverDatabaseName': parameter('NEW Silver catalog database name.', DATABASE_PATTERN),
        'GoldDatabaseName': parameter('NEW Gold catalog database name; different from Silver.', DATABASE_PATTERN),
        'ProjectTag': parameter('Project tag.', r'[A-Za-z0-9 _./=+-]{1,128}', 'FIAP-TC-Fase2'),
    }
    for layer in LAYERS:
        title = layer.title()
        parameters[title + 'JobName'] = parameter('NEW ' + title + ' job name.', NAME_PATTERN)
        parameters[title + 'RoleArn'] = parameter('Existing execution role ARN for ' + layer + '; no IAM resource is created.', ROLE_PATTERN)
        parameters[title + 'ScriptKey'] = parameter('Existing content-addressed script object under AssetsBucketName.',
            r'scripts/[A-Za-z0-9_-]{1,200}/[a-f0-9]{64}/' + layer + r'_glue\.py')
    for source in ('bronze', 'silver'):
        parameters[source.title() + 'ManifestKey'] = parameter(
            'Explicit successful ' + source + ' manifest key in DataBucketName, or empty bootstrap value. '
            'No success/content verification is performed by CloudFormation.',
            r'(?:|auditoria/' + source + r'/(?:[A-Za-z0-9_.=-]+/)*run_id=[A-Za-z0-9_-]{1,200}/manifest\.json)', '')
    conditions = {source.title() + 'ManifestProvided': {'Fn::Not': [
        {'Fn::Equals': [ref(source.title() + 'ManifestKey'), '']}]} for source in ('bronze', 'silver')}
    resources = {
        'SilverDatabase': retained('AWS::Glue::Database', {
            'CatalogId': ref('AWS::AccountId'),
            'DatabaseInput': {'Name': ref('SilverDatabaseName'),
                              'Description': 'FIAP Silver: consume only approved run manifests.'}}),
        'GoldDatabase': retained('AWS::Glue::Database', {
            'CatalogId': ref('AWS::AccountId'),
            'DatabaseInput': {'Name': ref('GoldDatabaseName'),
                              'Description': 'FIAP Gold: consume only approved run manifests.'}}),
    }
    for layer in LAYERS:
        title = layer.title()
        args = {'--job-bookmark-option': 'job-bookmark-disable'}
        if layer == 'bronze':
            args.update({'--BUCKET': ref('DataBucketName'), '--PREFIX': 'bronze/inep',
                '--AUDIT_PREFIX': 'auditoria/bronze', '--CONNECTION_NAME': ref('ConnectionName'),
                '--PARENT_PROJECT': ref('ParentProject'), '--SOURCE_DATASET': ref('SourceDataset'),
                '--TABLES': TABLES})
        else:
            args.update({'--enable-glue-datacatalog': '', '--enable-metrics': '',
                '--enable-continuous-cloudwatch-log': 'true', '--enable-spark-ui': 'false',
                '--TempDir': sub('s3://${AssetsBucketName}/temporary/${' + title + 'JobName}/'),
                '--LIMIAR_JOIN': '0.95', '--REGISTER_CATALOG': 'true',
                '--DATABASE_SILVER': ref('SilverDatabase')})
            source = 'Bronze' if layer == 'silver' else 'Silver'
            args['--' + source.upper() + '_MANIFEST_URI'] = {'Fn::If': [
                source + 'ManifestProvided', sub('s3://${DataBucketName}/${' + source + 'ManifestKey}'), '']}
            if layer == 'silver':
                args.update({'--BUCKET': ref('DataBucketName'), '--PREFIX': 'silver/inep',
                    '--AUDIT_PREFIX': 'auditoria/silver', '--ALUNOS_PARTITIONS': '4'})
            else:
                args.update({'--S3_BUCKET': ref('DataBucketName'), '--GOLD_PREFIX': 'gold/inep',
                    '--AUDIT_PREFIX': 'auditoria/gold', '--DATABASE_GOLD': ref('GoldDatabase'),
                    '--TOLERANCIA_PP': '0.1', '--DEMO_FAILURE': 'false'})
        properties = {
            'Name': ref(title + 'JobName'), 'Role': ref(title + 'RoleArn'),
            'Description': 'FIAP ' + title + ': stopped job configuration; explicit source manifests required.',
            'Command': {'Name': 'glueetl', 'PythonVersion': '3',
                        'ScriptLocation': sub('s3://${AssetsBucketName}/${' + title + 'ScriptKey}')},
            'DefaultArguments': args, 'ExecutionProperty': {'MaxConcurrentRuns': 1},
            'MaxRetries': 0, 'Timeout': 30 if layer == 'bronze' else 15,
            'GlueVersion': '5.1', 'WorkerType': 'G.1X', 'NumberOfWorkers': 2,
            'ExecutionClass': 'STANDARD',
            'Tags': [{'Key': 'Project', 'Value': ref('ProjectTag')},
                     {'Key': 'Component', 'Value': layer + '-inep'}],
        }
        if layer == 'bronze':
            properties['Connections'] = {'Connections': [ref('ConnectionName')]}
        resources[title + 'Job'] = retained('AWS::Glue::Job', properties)
    assertions = []
    for a, b in (('BronzeJobName', 'SilverJobName'), ('BronzeJobName', 'GoldJobName'),
                  ('SilverJobName', 'GoldJobName'), ('SilverDatabaseName', 'GoldDatabaseName')):
        assertions.append({'Assert': {'Fn::Not': [{'Fn::Equals': [ref(a), ref(b)]}]},
                           'AssertDescription': a + ' and ' + b + ' must differ.'})
    return {
        'AWSTemplateFormatVersion': '2010-09-09',
        'Description': 'OFFLINE PROPOSAL: three NEW stopped Glue jobs and two retained databases; assets must already exist.',
        'Metadata': dict(common_metadata(), Bootstrap='Empty source manifests fail closed; provide an approved URI before each future execution.'),
        'Parameters': parameters, 'Conditions': conditions,
        'Rules': {'DistinctResourceNames': {'Assertions': assertions}}, 'Resources': resources,
        'Outputs': {
            **{layer.title() + 'JobName': {'Value': ref(layer.title() + 'Job')} for layer in LAYERS},
            **{layer.title() + 'JobArn': {'Value': sub('arn:${AWS::Partition}:glue:${AWS::Region}:${AWS::AccountId}:job/${' + layer.title() + 'Job}')} for layer in LAYERS},
            'SilverDatabaseName': {'Value': ref('SilverDatabase')},
            'GoldDatabaseName': {'Value': ref('GoldDatabase')},
        },
    }


def valid_bucket(value):
    if (not isinstance(value, str) or not re.fullmatch(BUCKET_PATTERN, value)
            or any(s in value for s in ('..', '.-', '-.'))
            or re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+', value)
            or value.startswith(('xn--', 'sthree-', 'amzn-s3-demo-'))
            or value.endswith(('-s3alias', '--ol-s3', '.mrap', '--x-s3', '--table-s3'))):
        raise ValueError('Invalid or reserved S3 bucket name')
    return value


def fullmatch(value, pattern, label):
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError('Invalid ' + label)
    return value


def read_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding='utf-8-sig'), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Non-finite JSON number')))


def asset_manifest(assets_bucket, names):
    valid_bucket(assets_bucket)
    scripts = {}
    for layer in LAYERS:
        name = fullmatch(names[layer], NAME_PATTERN, layer + ' job name')
        file = ROOT / layer / (layer + '_glue.py')
        content = file.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        key = 'scripts/' + name + '/' + digest + '/' + file.name
        scripts[layer] = {'local_file': file.relative_to(ROOT).as_posix(), 'sha256': digest,
                          'bytes': len(content), 'uri': 's3://' + assets_bucket + '/' + key}
    return {'schema': 'fiap.batch.assets.v1', 'status': 'PENDING_UPLOAD',
            'cloud_verified': False, 'assets_bucket': assets_bucket, 'scripts': scripts}


def uri_key(uri, bucket, label):
    parsed = urlsplit(uri or '')
    if (parsed.scheme != 's3' or parsed.netloc != bucket or not parsed.path.startswith('/')
            or not parsed.path.strip('/') or parsed.query or parsed.fragment
            or parsed.username or parsed.password):
        raise ValueError(label + ' must be an S3 URI in the configured bucket')
    key = parsed.path[1:]
    if any(part in ('', '.', '..') for part in key.split('/')):
        raise ValueError(label + ' has an invalid path')
    return key


def manifest_key(uri, bucket, layer):
    if uri == '':
        return ''
    key = uri_key(uri, bucket, layer + ' manifest')
    parts = key.split('/')
    if (len(parts) < 4 or parts[:2] != ['auditoria', layer] or parts[-1] != 'manifest.json'
            or not re.fullmatch(r'run_id=[A-Za-z0-9_-]{1,200}', parts[-2])
            or sum(p.startswith('run_id=') for p in parts) != 1
            or any(not re.fullmatch(r'[A-Za-z0-9_.=-]+', p) for p in parts)):
        raise ValueError('Select exactly one auditoria/' + layer + '/.../run_id=ID/manifest.json')
    return key


def prepare_parameters(config, assets):
    expected = {'account_id', 'region', 'data_bucket', 'assets_bucket', 'jobs', 'roles',
                'connection_name', 'parent_project', 'source_dataset', 'silver_database',
                'gold_database', 'bronze_manifest_uri', 'silver_manifest_uri'}
    if not isinstance(config, dict) or set(config) != expected:
        raise ValueError('Configuration must contain exactly the keys in ambiente.example.json')
    fullmatch(config['account_id'], r'[0-9]{12}', 'expected account')
    region = fullmatch(config['region'], r'[a-z]{2}(?:-[a-z]+)+-[0-9]+', 'region')
    partition = 'aws-cn' if region.startswith('cn-') else ('aws-us-gov' if region.startswith('us-gov-') else 'aws')
    data_bucket, assets_bucket = valid_bucket(config['data_bucket']), valid_bucket(config['assets_bucket'])
    if data_bucket == assets_bucket:
        raise ValueError('The storage proposal requires different data and assets bucket names')
    for field in ('jobs', 'roles'):
        if not isinstance(config[field], dict) or set(config[field]) != set(LAYERS):
            raise ValueError(field + ' must specify all three layers exactly')
    names = {layer: fullmatch(config['jobs'][layer], NAME_PATTERN, layer + ' job') for layer in LAYERS}
    if len(set(names.values())) != 3:
        raise ValueError('Job names must be different')
    role_values = {}
    for layer in LAYERS:
        arn = fullmatch(config['roles'][layer], ROLE_PATTERN, layer + ' role ARN')
        match = re.fullmatch(ROLE_PATTERN, arn)
        if match.group(1) != partition or match.group(2) != config['account_id']:
            raise ValueError('Role must belong to the expected account and region partition')
        role_values[layer.title() + 'RoleArn'] = arn
    fullmatch(config['connection_name'], r'[A-Za-z0-9_ .()/-]{1,200}', 'connection name')
    if not config['connection_name'].strip():
        raise ValueError('Connection name must not be blank')
    fullmatch(config['parent_project'], r'[a-z][a-z0-9-]{4,61}[a-z0-9]', 'GCP consumer project')
    fullmatch(config['source_dataset'], r'[a-z][a-z0-9-]{4,61}[a-z0-9]\.[A-Za-z_][A-Za-z0-9_]*', 'source dataset')
    for field in ('silver_database', 'gold_database'):
        fullmatch(config[field], DATABASE_PATTERN, field)
    if config['silver_database'] == config['gold_database']:
        raise ValueError('Silver and Gold databases must differ')
    if (not isinstance(assets, dict) or set(assets) != {'schema', 'status', 'cloud_verified', 'assets_bucket', 'scripts'}
            or assets['schema'] != 'fiap.batch.assets.v1' or assets['status'] != 'PENDING_UPLOAD'
            or assets['cloud_verified'] is not False or assets['assets_bucket'] != assets_bucket
            or not isinstance(assets['scripts'], dict) or set(assets['scripts']) != set(LAYERS)):
        raise ValueError('Expected an offline PENDING_UPLOAD asset manifest for the configured bucket')
    expected_assets = asset_manifest(assets_bucket, names)
    if assets != expected_assets:
        raise ValueError('Asset manifest differs from the local scripts, hashes, names or expected URIs')
    values = {'DataBucketName': data_bucket, 'AssetsBucketName': assets_bucket,
              'ConnectionName': config['connection_name'], 'ParentProject': config['parent_project'],
              'SourceDataset': config['source_dataset'], 'SilverDatabaseName': config['silver_database'],
              'GoldDatabaseName': config['gold_database'], **role_values}
    for layer in LAYERS:
        values[layer.title() + 'JobName'] = names[layer]
        values[layer.title() + 'ScriptKey'] = uri_key(assets['scripts'][layer]['uri'], assets_bucket, layer + ' script')
    states = {}
    for layer in ('bronze', 'silver'):
        values[layer.title() + 'ManifestKey'] = manifest_key(config[layer + '_manifest_uri'], data_bucket, layer)
        states[layer] = ('EMPTY_BOOTSTRAP_FAIL_CLOSED' if values[layer.title() + 'ManifestKey'] == ''
                         else 'URI_VALIDATED_ONLY_SUCCESS_AND_CONTENT_NOT_CHECKED')
    to_parameters = lambda entries: [{'ParameterKey': key, 'ParameterValue': str(value)} for key, value in sorted(entries.items())]
    return {
        'storage_parameters.json': to_parameters({key: values[key] for key in ('DataBucketName', 'AssetsBucketName')}),
        'batch_parameters.json': to_parameters(values),
        'local_plan.json': {
            'status': 'OFFLINE_PROPOSAL_NOT_DEPLOYED', 'cloud_calls': 0,
            'expected_account': config['account_id'], 'expected_region': region,
            'identity_or_region_verified_in_cloud': False, 'scripts_uploaded_or_verified_in_cloud': False,
            'manifest_states': states, 'jobs_started': False, 'import_ready': False,
            'next_step': 'Review prerequisites and costs. Upload and verify assets separately before any future batch stack creation.',
        },
    }


def encode(value):
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'


def write_new(path, value):
    path = Path(path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(encode(value))


def write_directory(directory, values):
    directory = Path(directory).expanduser().resolve()
    serialized = {name: encode(value) for name, value in values.items()}
    directory.mkdir(parents=True, exist_ok=False)
    for name, content in serialized.items():
        with (directory / name).open('x', encoding='utf-8', newline='\n') as handle:
            handle.write(content)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    templates = commands.add_parser('templates', help='Write new-environment storage and batch templates only')
    templates.add_argument('--output-dir', required=True)
    assets = commands.add_parser('assets', help='Hash local scripts and prepare a manifest; no upload')
    assets.add_argument('--assets-bucket', required=True)
    for layer in LAYERS:
        assets.add_argument('--' + layer + '-job', required=True)
    assets.add_argument('--output', required=True)
    parameters = commands.add_parser('parameters', help='Validate local configuration and script manifest; no AWS clients')
    parameters.add_argument('--config', required=True)
    parameters.add_argument('--assets-manifest', '--asset-manifest', dest='assets_manifest', required=True)
    parameters.add_argument('--output-dir', required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'templates':
            write_directory(args.output_dir, {'storage_stack.json': build_storage(), 'batch_stack.json': build_batch()})
        elif args.command == 'assets':
            names = {layer: getattr(args, layer + '_job') for layer in LAYERS}
            write_new(args.output, asset_manifest(args.assets_bucket, names))
        else:
            write_directory(args.output_dir, prepare_parameters(read_json(args.config), read_json(args.assets_manifest)))
    except (ValueError, OSError, TypeError, KeyError) as exc:
        parser.error(str(exc))
    result = {'operation': args.command, 'cloud_calls': 0, 'deployed': False, 'scripts_uploaded': False, 'jobs_started': False}
    print(encode(result), end='')
    return result


if __name__ == '__main__':
    main()
